import * as React from "react";
import { cn } from "../../../utils/cn";
import { labelVariants } from "./variants/label.variants";
import type { LabelProps } from "./types/label.types";

/**
 * Label — texte associé à un champ (input, select, checkbox…).
 *
 * Objectifs :
 * - Style uniforme et moderne
 * - Cliquable quand `htmlFor` est fourni (focus du champ)
 * - Support de l’état required (astérisque)
 */
export const Label = React.forwardRef<HTMLLabelElement, LabelProps>(function Label(
  {
    className,
    uiSize = "md",
    tone = "default",
    required,
    requiredIndicator = "*",
    requiredSrText = "required",
    children,
    htmlFor,
    onClick,
    ...rest
  },
  ref,
) {
  const handleClick: React.MouseEventHandler<HTMLLabelElement> = (event) => {
    onClick?.(event);
    if (event.defaultPrevented) return;
    if (htmlFor) {
      const target = document.getElementById(htmlFor);
      if (target instanceof HTMLElement) target.focus();
    }
  };

  return (
    <label
      ref={ref}
      htmlFor={htmlFor}
      className={cn(labelVariants({ uiSize, tone }), className)}
      onClick={handleClick}
      {...rest}
    >
      <span className={cn("min-w-0 truncate")}>{children}</span>

      {required ? (
        <span className={cn("inline-flex items-center gap-1")}>
          <span aria-hidden="true" className={cn("text-red-600")}>
            {requiredIndicator}
          </span>
          <span className={cn("sr-only")}>{requiredSrText}</span>
        </span>
      ) : null}
    </label>
  );
});

Label.displayName = "Label";
