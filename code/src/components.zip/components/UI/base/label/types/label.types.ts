import type * as React from "react";
import type { WithClassName, WithChildren } from "../../../utils/types";

/** Tailles typographiques du label. */
export type LabelSize = "sm" | "md";

/** Ton (couleur) du label selon le contexte (ex: normal / muted / error / disabled). */
export type LabelTone = "default" | "muted" | "error" | "disabled";

export type LabelProps = WithClassName<
  WithChildren<
    React.LabelHTMLAttributes<HTMLLabelElement> & {
      /** Taille du label. Par défaut: "md". */
      uiSize?: LabelSize;

      /** Ton visuel du label. Par défaut: "default". */
      tone?: LabelTone;

      /** Affiche un indicateur "required" (astérisque par défaut). */
      required?: boolean;

      /** Personnalise l'indicateur required (par défaut "*"). */
      requiredIndicator?: React.ReactNode;

      /**
       * Ajoute un texte uniquement pour les lecteurs d'écran après l'indicateur required.
       * Par défaut: "required".
       */
      requiredSrText?: string;
    }
  >
>;
