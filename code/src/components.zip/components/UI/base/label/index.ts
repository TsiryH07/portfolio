export { Label } from "./label";
export type { LabelProps, LabelSize, LabelTone } from "./types/label.types";
export { labelVariants } from "./variants/label.variants";
