import { cn } from "../../../../utils/cn";
import { UI_DURATIONS } from "../../../../utils/constants";
import type { LabelSize, LabelTone } from "../types/label.types";

/**
 * Variants visuels du Label.
 * - Centralise les classes Tailwind et évite les concat.
 */
export function labelVariants(opts?: { uiSize?: LabelSize; tone?: LabelTone }) {
  const uiSize = opts?.uiSize ?? "md";
  const tone = opts?.tone ?? "default";

  const base = cn(
    "inline-flex items-center gap-1",
    "select-none",
    "leading-none",
    "transition-colors",
    UI_DURATIONS.normal,
  );

  const sizes: Record<LabelSize, string> = {
    sm: cn("text-sm"),
    md: cn("text-sm font-medium"),
  };

  const tones: Record<LabelTone, string> = {
    default: cn("text-slate-900"),
    muted: cn("text-slate-600"),
    error: cn("text-red-600"),
    disabled: cn("text-slate-500 opacity-80"),
  };

  return cn(base, sizes[uiSize], tones[tone]);
}
