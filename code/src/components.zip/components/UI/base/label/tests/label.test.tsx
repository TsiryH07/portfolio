import { describe, it, expect } from "vitest";
import * as React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Label } from "../label";

describe("Label", () => {
  it("renders children", () => {
    render(<Label>Email</Label>);
    expect(screen.getByText("Email")).toBeInTheDocument();
  });

  it("passes htmlFor and is clickable to focus the associated input", () => {
    render(
      <div>
        <Label htmlFor="email">Email</Label>
        <input id="email" aria-label="Email field" />
      </div>,
    );

    const input = screen.getByLabelText("Email field");
    expect(input).not.toHaveFocus();

    fireEvent.click(screen.getByText("Email"));
    expect(input).toHaveFocus();
  });

  it("renders required indicator with sr-only text", () => {
    render(<Label required>Username</Label>);
    expect(screen.getByText("Username")).toBeInTheDocument();
    // indicator is visible
    expect(screen.getByText("*")).toBeInTheDocument();
    // sr-only text is in the DOM
    expect(screen.getByText("required")).toBeInTheDocument();
  });

  it("supports custom required indicator", () => {
    render(
      <Label required requiredIndicator="(required)">
        Name
      </Label>,
    );
    expect(screen.getByText("(required)")).toBeInTheDocument();
  });

  it("applies size and tone classes", () => {
    render(
      <Label uiSize="sm" tone="muted">
        Hint
      </Label>,
    );
    const el = screen.getByText("Hint").closest("label")!;
    expect(el.className).toContain("text-sm");
    expect(el.className).toContain("text-slate-600");
  });

  it("tone=error applies error styling", () => {
    render(<Label tone="error">Error</Label>);
    const el = screen.getByText("Error").closest("label")!;
    expect(el.className).toContain("text-red-600");
  });
});
