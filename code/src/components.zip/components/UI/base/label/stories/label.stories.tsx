import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Label } from "../label";

const meta: Meta<typeof Label> = {
  title: "base/Label",
  component: Label,
  args: {
    children: "Label",
    uiSize: "md",
    tone: "default",
  },
};
export default meta;

type Story = StoryObj<typeof Label>;

export const Playground: Story = {};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "grid", gap: 6 }}>
        <Label uiSize="sm">Small label</Label>
        <input
          id="x"
          aria-label="x"
          style={{ border: "1px solid #e2e8f0", padding: 8, borderRadius: 8 }}
        />
      </div>
      <div style={{ display: "grid", gap: 6 }}>
        <Label uiSize="md">Medium label</Label>
        <input
          id="y"
          aria-label="y"
          style={{ border: "1px solid #e2e8f0", padding: 8, borderRadius: 8 }}
        />
      </div>
    </div>
  ),
};

export const Required: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 10 }}>
      <Label htmlFor="email" required>
        Email
      </Label>
      <input
        id="email"
        aria-label="Email"
        style={{ border: "1px solid #e2e8f0", padding: 8, borderRadius: 8 }}
      />
    </div>
  ),
};

export const Tones: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
      <Label tone="default">Default</Label>
      <Label tone="muted">Muted</Label>
      <Label tone="error" required>
        Error required
      </Label>
      <Label tone="disabled">Disabled</Label>
    </div>
  ),
};

export const WithCheckbox: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
      <input id="terms" type="checkbox" />
      <Label htmlFor="terms" required>
        I accept the terms
      </Label>
    </div>
  ),
};
