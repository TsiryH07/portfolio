import { describe, it, expect, vi } from "vitest";
import * as React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Checkbox } from "../checkbox";

describe("Checkbox", () => {
  it("renders and toggles via label click", () => {
    const onCheckedChange = vi.fn();
    render(<Checkbox label="Accept" onCheckedChange={onCheckedChange} />);
    const input = screen.getByRole("checkbox", { name: "Accept" });
    const label = screen.getByText("Accept");
    fireEvent.click(label);
    expect(onCheckedChange).toHaveBeenCalledWith(true);
    expect(input).toBeInTheDocument();
  });

  it("supports indeterminate state (DOM property)", () => {
    render(<Checkbox label="Maybe" indeterminate />);
    const input = screen.getByRole("checkbox", { name: "Maybe" }) as HTMLInputElement;
    expect(input.indeterminate).toBe(true);
    expect(input).toHaveAttribute("aria-checked", "mixed");
  });

  it("sets aria-invalid and describes error", () => {
    render(<Checkbox label="Accept" error="Required" />);
    const input = screen.getByRole("checkbox", { name: "Accept" });
    expect(input).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByText("Required")).toBeInTheDocument();
    expect(input.getAttribute("aria-describedby") ?? "").toContain("error");
  });

  it("does not call onCheckedChange when disabled", () => {
    const onCheckedChange = vi.fn();
    render(<Checkbox label="Accept" disabled onCheckedChange={onCheckedChange} />);
    fireEvent.click(screen.getByText("Accept"));
    expect(onCheckedChange).not.toHaveBeenCalled();
  });

  it("shows required indicator when required", () => {
    render(<Checkbox label="Accept" required />);
    expect(screen.getByText("*")).toBeInTheDocument();
  });
});
