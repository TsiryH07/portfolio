import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Checkbox } from "../checkbox";

const meta: Meta<typeof Checkbox> = {
  title: "base/Checkbox",
  component: Checkbox,
  args: {
    label: "Receive updates",
    uiSize: "md",
  },
  argTypes: {
    uiSize: { control: "select", options: ["sm", "md", "lg"] },
    indeterminate: { control: "boolean" },
    disabled: { control: "boolean" },
    required: { control: "boolean" },
  },
};
export default meta;

type Story = StoryObj<typeof Checkbox>;

export const Playground: Story = {
  render: (args) => {
    const [checked, setChecked] = React.useState(false);
    return (
      <Checkbox
        {...args}
        checked={checked}
        onCheckedChange={(v) => setChecked(v)}
        onChange={(e) => args.onChange?.(e)}
      />
    );
  },
};

export const States: Story = {
  parameters: { controls: { disable: true } },
  render: () => (
    <div style={{ display: "grid", gap: 14, maxWidth: 420 }}>
      <Checkbox label="Unchecked" />
      <Checkbox label="Checked" defaultChecked />
      <Checkbox label="Indeterminate" indeterminate />
      <Checkbox label="Disabled" disabled />
      <Checkbox label="Error" error="You must accept." />
      <Checkbox
        label="With description"
        description="We’ll only email you when there’s something important."
        helperText="You can change this anytime."
      />
    </div>
  ),
};

export const Sizes: Story = {
  parameters: { controls: { disable: true } },
  render: () => (
    <div style={{ display: "grid", gap: 14, maxWidth: 420 }}>
      <Checkbox uiSize="sm" label="Small" />
      <Checkbox uiSize="md" label="Medium" defaultChecked />
      <Checkbox uiSize="lg" label="Large" indeterminate />
    </div>
  ),
};
