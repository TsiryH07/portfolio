import type * as React from "react";
import type { Nullable, WithClassName } from "../../../utils/types";

export type CheckboxSize = "sm" | "md" | "lg";

export type CheckboxIds = Readonly<{
  root: string;
  label: string;
  help: string;
  error: string;
  description: string;
}>;

/**
 * Checkbox
 * - Indeterminate via `indeterminate`
 * - Label cliquable via htmlFor/id
 * - Description / helper / error reliés via aria-describedby
 */
export type CheckboxProps = WithClassName<
  Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "size"> & {
    uiSize?: CheckboxSize;

    /** Texte à droite (ou JSX) pour nom accessible + click. */
    label?: React.ReactNode;

    /** Description sous le label (optionnel). */
    description?: React.ReactNode;

    /** Texte d’aide sous le champ (si pas d’erreur). */
    helperText?: React.ReactNode;

    /** Message d’erreur (affiche aussi aria-invalid). */
    error?: Nullable<React.ReactNode>;

    /** Supporte l’état indéterminé (aria-checked=mixed + rendu). */
    indeterminate?: boolean;

    /**
     * Callback ergonomique (en plus de onChange natif).
     * Appelé avec le booléen `checked` (ou true quand indeterminate est togglé).
     */
    onCheckedChange?: (checked: boolean) => void;

    /** Classe pour le wrapper externe. */
    containerClassName?: string;

    /** Classe pour la “box” (le carré). */
    checkboxClassName?: string;

    /**
     * Affiche l’astérisque si `required` est true (par défaut true).
     * Utile si tu gères le required ailleurs et ne veux pas d’indicateur.
     */
    showRequiredIndicator?: boolean;
  }
>;
