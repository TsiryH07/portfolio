import * as React from "react";
import { cn } from "../../../utils/cn";
import { createScopedIds } from "../../../utils/id";
import { checkboxVariants } from "./variants/checkbox.variants";
import type { CheckboxIds, CheckboxProps } from "./types/checkbox.types";

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  {
    className,
    containerClassName,
    checkboxClassName,
    uiSize = "md",
    label,
    description,
    helperText,
    error,
    indeterminate,
    onCheckedChange,
    showRequiredIndicator = true,
    disabled,
    id,
    required,
    checked,
    defaultChecked,
    onChange,
    "aria-describedby": ariaDescribedByProp,
    ...rest
  },
  ref,
) {
  const hasError = Boolean(error);
  const isDisabled = Boolean(disabled);

  const ids = React.useMemo<CheckboxIds>(() => {
    if (id) {
      const sep = "-";
      return Object.freeze({
        root: id,
        label: `${id}${sep}label`,
        help: `${id}${sep}help`,
        error: `${id}${sep}error`,
        description: `${id}${sep}desc`,
      });
    }
    return createScopedIds("checkbox");
  }, [id]);

  const describedByIds = [
    ariaDescribedByProp,
    description ? ids.description : null,
    helperText ? ids.help : null,
    hasError ? ids.error : null,
  ]
    .filter(Boolean)
    .join(" ");

  const a11yProps = {
    id: ids.root,
    "aria-invalid": hasError || undefined,
    "aria-describedby": describedByIds.length ? describedByIds : undefined,
    "aria-checked": indeterminate ? ("mixed" as const) : undefined,
  } as const;

  const internalRef = React.useRef<HTMLInputElement | null>(null);

  const setRef = React.useCallback(
    (node: HTMLInputElement | null) => {
      internalRef.current = node;
      if (!ref) return;
      if (typeof ref === "function") ref(node);
      else (ref as React.MutableRefObject<HTMLInputElement | null>).current = node;
    },
    [ref],
  );

  // Indeterminate must be set via DOM property.
  React.useEffect(() => {
    if (!internalRef.current) return;
    internalRef.current.indeterminate = Boolean(indeterminate);
  }, [indeterminate]);

  const isChecked = Boolean(checked ?? defaultChecked);
  const isIndeterminate = Boolean(indeterminate);

  const v = checkboxVariants({
    uiSize,
    hasError,
    isDisabled,
    isChecked,
    isIndeterminate,
  });

  const handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    onChange?.(e);
    // If indeterminate, common UX is to go to checked on first interaction.
    const nextChecked = indeterminate ? true : e.currentTarget.checked;
    onCheckedChange?.(nextChecked);
  };

  return (
    <div className={cn("grid gap-1.5", containerClassName, className)}>
      <div className={cn(v.row)}>
        <input
          ref={setRef}
          type="checkbox"
          disabled={disabled}
          checked={checked}
          defaultChecked={defaultChecked}
          onChange={handleChange}
          className={cn("peer sr-only")}
          required={required}
          {...a11yProps}
          {...rest}
        />

        <div
          aria-hidden="true"
          data-state={isIndeterminate ? "indeterminate" : isChecked ? "checked" : "unchecked"}
          className={cn(v.box, checkboxClassName)}
        >
          <CheckboxMark
            state={isIndeterminate ? "indeterminate" : isChecked ? "checked" : "unchecked"}
            className={cn(v.mark)}
          />
        </div>

        {label || description ? (
          <div className={cn("min-w-0")}>
            {label ? (
              <label id={ids.label} htmlFor={ids.root} className={cn(v.label)}>
                <span className={cn("align-middle")}>{label}</span>
                {showRequiredIndicator && required ? (
                  <span aria-hidden="true" className={cn("ml-1 text-red-600")}>
                    *
                  </span>
                ) : null}
              </label>
            ) : null}

            {description ? (
              <div id={ids.description} className={cn(v.description)}>
                {description}
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      {hasError ? (
        <div id={ids.error} className={cn(v.error)}>
          {error}
        </div>
      ) : helperText ? (
        <div id={ids.help} className={cn(v.helper)}>
          {helperText}
        </div>
      ) : null}
    </div>
  );
});

Checkbox.displayName = "Checkbox";

function CheckboxMark(props: { state: "checked" | "unchecked" | "indeterminate"; className?: string }) {
  const { state, className } = props;

  return (
    <span className={cn("relative grid place-items-center", className)}>
      <svg
        viewBox="0 0 24 24"
        className={cn(
          "absolute inset-0 m-auto",
          "transition-all",
          state === "checked" ? "opacity-100 scale-100" : "opacity-0 scale-75",
        )}
        fill="none"
        aria-hidden="true"
      >
        <path
          d="M20 6L9 17l-5-5"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      <span
        aria-hidden="true"
        className={cn(
          "absolute m-auto h-0.5 w-3.5 rounded-full bg-current",
          "transition-all",
          state === "indeterminate" ? "opacity-100 scale-100" : "opacity-0 scale-75",
        )}
      />
    </span>
  );
}
