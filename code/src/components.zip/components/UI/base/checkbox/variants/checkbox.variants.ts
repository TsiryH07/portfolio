import { cn } from "../../../../utils/cn";
import { UI_DURATIONS, UI_RADII } from "../../../../utils/constants";
import type { CheckboxSize } from "../types/checkbox.types";

export function checkboxVariants(opts?: {
  uiSize?: CheckboxSize;
  hasError?: boolean;
  isDisabled?: boolean;
  isChecked?: boolean;
  isIndeterminate?: boolean;
}) {
  const uiSize = opts?.uiSize ?? "md";

  const sizes: Record<CheckboxSize, { box: string; mark: string; label: string; gap: string }> = {
    sm: { box: "h-4 w-4", mark: "h-3 w-3", label: "text-sm", gap: "gap-2" },
    md: { box: "h-5 w-5", mark: "h-3.5 w-3.5", label: "text-sm", gap: "gap-2.5" },
    lg: { box: "h-6 w-6", mark: "h-4 w-4", label: "text-base", gap: "gap-3" },
  };

  const box = cn(
    "relative inline-flex items-center justify-center shrink-0",
    "border border-slate-200 bg-white shadow-sm",
    UI_RADII.sm,
    "transition-colors",
    UI_DURATIONS.normal,
    // Focus (clavier)
    "peer-focus-visible:ring-2 peer-focus-visible:ring-slate-400 peer-focus-visible:ring-offset-2",
    "peer-focus-visible:border-slate-300",
    // Hover
    "hover:border-slate-300",
    // Size
    sizes[uiSize].box,
    // Checked / indeterminate
    (opts?.isChecked || opts?.isIndeterminate) && "bg-slate-900 border-slate-900 text-white",
    // Disabled
    opts?.isDisabled && "bg-slate-50 border-slate-200 text-slate-500 opacity-80 cursor-not-allowed",
    // Error
    opts?.hasError &&
      cn(
        "border-red-500",
        "peer-focus-visible:ring-red-400 peer-focus-visible:border-red-500",
        "hover:border-red-500",
      ),
  );

  const mark = cn(
    "pointer-events-none",
    "transition-all",
    UI_DURATIONS.normal,
    sizes[uiSize].mark,
  );

  const label = cn(
    "font-medium text-slate-900 leading-snug",
    sizes[uiSize].label,
    opts?.isDisabled && "text-slate-500 cursor-not-allowed",
  );

  const description = cn("text-sm text-slate-600");
  const helper = cn("text-sm text-slate-600");
  const error = cn("text-sm text-red-600");

  const row = cn("flex items-start", sizes[uiSize].gap);

  return {
    row,
    box,
    mark,
    label,
    description,
    helper,
    error,
  };
}
