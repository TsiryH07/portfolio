import type * as React from "react";
import type { WithClassName } from "../../../utils/types";

/**
 * Variants visuels du Button.
 * - "primary" : action principale
 * - "secondary" : action alternative
 * - "ghost" : action discrète
 * - "destructive" : action dangereuse (supprimer, etc.)
 * - "link" : rendu lien (underline au hover)
 * - "outline" : bordure + fond transparent
 */
export type ButtonVariant =
  | "primary"
  | "secondary"
  | "ghost"
  | "destructive"
  | "link"
  | "outline";

/** Tailles du Button. */
export type ButtonSize = "sm" | "md" | "lg" | "icon";

/** Position de l'icône dans le Button. */
export type ButtonIconPosition = "left" | "right";

/**
 * Props publiques du Button.
 *
 * Notes :
 * - `asChild` permet de styliser un autre élément racine (ex: <a>, <Link>), via Slot.
 * - `isLoading` désactive le bouton et affiche un spinner.
 * - `leftIcon` / `rightIcon` sont des ReactNode (SVG, icône, etc.).
 */
export type ButtonProps = WithClassName<
  React.ButtonHTMLAttributes<HTMLButtonElement> & {
    asChild?: boolean;

    variant?: ButtonVariant;
    size?: ButtonSize;

    isLoading?: boolean;
    /** Texte optionnel à afficher pendant le loading (par défaut: children). */
    loadingText?: React.ReactNode;

    leftIcon?: React.ReactNode;
    rightIcon?: React.ReactNode;

    /** Largeur pleine (utile en mobile / formulaires). */
    fullWidth?: boolean;
  }
>;
