import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Button } from "../button";

const meta: Meta<typeof Button> = {
  title: "base/Button",
  component: Button,
  args: {
    children: "Button",
    variant: "primary",
    size: "md",
  },
};
export default meta;

type Story = StoryObj<typeof Button>;

const Icon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="none" {...props}>
    <path
      d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7l3-7z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinejoin="round"
    />
  </svg>
);

export const Playground: Story = {};

export const Variants: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      <Button variant="primary">Primary</Button>
      <Button variant="secondary">Secondary</Button>
      <Button variant="outline">Outline</Button>
      <Button variant="ghost">Ghost</Button>
      <Button variant="destructive">Destructive</Button>
      <Button variant="link">Link</Button>
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
      <Button size="sm">Small</Button>
      <Button size="md">Medium</Button>
      <Button size="lg">Large</Button>
      <Button size="icon" aria-label="Star">
        <Icon width={18} height={18} />
      </Button>
    </div>
  ),
};

export const WithIcons: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      <Button leftIcon={<Icon width={18} height={18} />}>Left icon</Button>
      <Button rightIcon={<Icon width={18} height={18} />}>Right icon</Button>
      <Button variant="secondary" leftIcon={<Icon width={18} height={18} />} rightIcon={<Icon width={18} height={18} />}>
        Both
      </Button>
    </div>
  ),
};

export const Loading: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
      <Button isLoading>Saving…</Button>
      <Button variant="secondary" isLoading loadingText="Please wait">
        Save
      </Button>
      <Button size="icon" isLoading aria-label="Loading" />
    </div>
  ),
};

export const AsChildLink: Story = {
  render: () => (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
      <Button asChild>
        <a href="#pricing">Link as Button</a>
      </Button>
      <Button asChild variant="secondary">
        <a href="#docs">Docs</a>
      </Button>
      <Button asChild variant="link">
        <a href="#plain">Plain link style</a>
      </Button>
    </div>
  ),
};

export const FullWidth: Story = {
  render: () => (
    <div style={{ width: 360, display: "grid", gap: 10 }}>
      <Button fullWidth>Continue</Button>
      <Button variant="secondary" fullWidth>
        Cancel
      </Button>
    </div>
  ),
};
