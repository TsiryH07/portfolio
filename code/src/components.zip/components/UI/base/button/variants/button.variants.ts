import { cn } from "../../../../utils/cn";
import { UI_DURATIONS, UI_RADII } from "../../../../utils/constants";
import type { ButtonSize, ButtonVariant } from "../types/button.types";

/**
 * buttonVariants — "cva-like" local
 *
 * Objectif :
 * - centraliser les classes Tailwind
 * - éviter les concat illisibles
 * - garder des variants testables et maintenables
 */
export function buttonVariants(opts?: {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  isDisabled?: boolean;
}) {
  const variant = opts?.variant ?? "primary";
  const size = opts?.size ?? "md";

  const base = cn(
    "inline-flex items-center justify-center gap-2 whitespace-nowrap select-none",
    "font-medium leading-none",
    "transition-colors",
    UI_DURATIONS.normal,
    UI_RADII.md,
    // Focus ring (clavier)
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400 focus-visible:ring-offset-2",
    // States
    "disabled:pointer-events-none disabled:opacity-50",
    // For asChild disabled simulation (we add these classes conditionally in the component)
    "data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50",
    // Smooth press feedback
    "active:translate-y-px",
    opts?.fullWidth && "w-full",
  );

  const sizes: Record<ButtonSize, string> = {
    sm: cn("h-9 px-3 text-sm"),
    md: cn("h-10 px-4 text-sm"),
    lg: cn("h-11 px-5 text-base"),
    icon: cn("h-10 w-10 p-0"),
  };

  const variants: Record<ButtonVariant, string> = {
    primary: cn(
      "bg-slate-900 text-white shadow-sm",
      "hover:bg-slate-800",
      "active:bg-slate-900",
    ),
    secondary: cn(
      "bg-slate-100 text-slate-900 shadow-sm",
      "hover:bg-slate-200",
      "active:bg-slate-100",
    ),
    ghost: cn(
      "bg-transparent text-slate-900",
      "hover:bg-slate-100",
      "active:bg-slate-200/60",
    ),
    outline: cn(
      "bg-transparent text-slate-900 border border-slate-200",
      "hover:bg-slate-50",
      "active:bg-slate-100/70",
    ),
    destructive: cn(
      "bg-red-600 text-white shadow-sm",
      "hover:bg-red-700",
      "active:bg-red-600",
      "focus-visible:ring-red-500",
    ),
    link: cn(
      "bg-transparent text-slate-900 px-0 h-auto",
      "underline underline-offset-4",
      "hover:text-slate-700",
      "active:text-slate-900",
      "focus-visible:ring-2 focus-visible:ring-slate-400 focus-visible:ring-offset-2",
    ),
  };

  // When disabled, some variants need to remove shadows/hover expectations.
  const disabledTweak =
    opts?.isDisabled && variant !== "link" ? cn("shadow-none") : undefined;

  return cn(base, sizes[size], variants[variant], disabledTweak);
}
