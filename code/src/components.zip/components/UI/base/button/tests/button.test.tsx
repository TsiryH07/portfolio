import { describe, it, expect, vi } from "vitest";
import * as React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Button } from "../button";

describe("Button", () => {
  it("renders children", () => {
    render(<Button>Save</Button>);
    expect(screen.getByRole("button", { name: "Save" })).toBeInTheDocument();
  });

  it("applies variant and size classes", () => {
    render(
      <Button variant="secondary" size="sm">
        Secondary
      </Button>,
    );
    const btn = screen.getByRole("button", { name: "Secondary" });
    // size
    expect(btn.className).toContain("h-9");
    // variant
    expect(btn.className).toContain("bg-slate-100");
  });

  it("disables and shows spinner when loading", () => {
    render(<Button isLoading>Loading</Button>);
    const btn = screen.getByRole("button", { name: "Loading" });
    expect(btn).toBeDisabled();
    // spinner is aria-hidden; the sr-only text contains "Loading"
    expect(btn.querySelector("svg")).toBeTruthy();
    expect(btn).toHaveAttribute("aria-busy", "true");
  });

  it("prevents click when disabled", () => {
    const onClick = vi.fn();
    render(
      <Button disabled onClick={onClick}>
        Click
      </Button>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Click" }));
    expect(onClick).not.toHaveBeenCalled();
  });

  it("supports asChild and passes styles to anchor", () => {
    render(
      <Button asChild variant="primary">
        <a href="/x">Go</a>
      </Button>,
    );
    const link = screen.getByRole("link", { name: "Go" });
    expect(link.className).toContain("bg-slate-900");
  });

  it("asChild disabled sets aria-disabled and blocks click", () => {
    const onClick = vi.fn();
    render(
      <Button asChild disabled onClick={onClick}>
        <a href="/x">Go</a>
      </Button>,
    );
    const link = screen.getByRole("link", { name: "Go" });
    expect(link).toHaveAttribute("aria-disabled", "true");
    fireEvent.click(link);
    expect(onClick).not.toHaveBeenCalled();
  });
});
