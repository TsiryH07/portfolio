import * as React from "react";
import { cn } from "../../../utils/cn";
import { Slot } from "../../../utils/slot";
import { buttonVariants } from "./variants/button.variants";
import type { ButtonProps } from "./types/button.types";

/**
 * Button — composant central d'action
 *
 * - Supporte `variant` + `size`
 * - Supporte `isLoading` (spinner + désactivation)
 * - Supporte `asChild` via Slot (Radix/shadcn pattern)
 * - Supporte icône gauche/droite
 */
export const Button = React.forwardRef<HTMLElement, ButtonProps>(function Button(
  {
    asChild,
    className,
    variant,
    size,
    fullWidth,
    isLoading,
    loadingText,
    leftIcon,
    rightIcon,
    disabled,
    onClick,
    type,
    children,
    ...rest
  },
  ref,
) {
  const Comp = asChild ? Slot : "button";
  const isDisabled = Boolean(disabled || isLoading);

  const handleClick: React.MouseEventHandler<any> = (e) => {
    if (isDisabled) {
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    onClick?.(e);
  };

  // For asChild: simulate disabled behavior for non-button elements.
  const asChildDisabledProps = asChild && isDisabled
    ? {
        "aria-disabled": true,
        tabIndex: -1,
        "data-disabled": "true",
      }
    : { "data-disabled": "false" as const };

  const commonClassName = cn(
    buttonVariants({ variant, size, fullWidth, isDisabled }),
    asChild && variant === "link" && "inline-flex",
    className,
    asChild && isDisabled && "pointer-events-none opacity-50",
  );

  if (asChild && React.isValidElement(children)) {
    const child = children as React.ReactElement;
    const childContent = (
      <ButtonContent
        isLoading={isLoading}
        loadingText={loadingText}
        leftIcon={leftIcon}
        rightIcon={rightIcon}
        size={size}
      >
        {child.props.children}
      </ButtonContent>
    );

    return (
      <Slot
        ref={ref as any}
        className={commonClassName}
        onClick={handleClick}
        aria-busy={isLoading || undefined}
        {...asChildDisabledProps}
        {...rest}
      >
        {React.cloneElement(child, { children: childContent })}
      </Slot>
    );
  }

  return (
    <button
      ref={ref as any}
      className={commonClassName}
      onClick={handleClick}
      type={type ?? "button"}
      disabled={isDisabled}
      aria-busy={isLoading || undefined}
      {...rest}
    >
      <ButtonContent
        isLoading={isLoading}
        loadingText={loadingText}
        leftIcon={leftIcon}
        rightIcon={rightIcon}
        size={size}
      >
        {children}
      </ButtonContent>
    </button>
  );
});

Button.displayName = "Button";

function ButtonContent(props: {
  isLoading?: boolean;
  loadingText?: React.ReactNode;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  size?: ButtonProps["size"];
  children?: React.ReactNode;
}) {
  const { isLoading, loadingText, leftIcon, rightIcon, size, children } = props;

  const content = isLoading ? (loadingText ?? children) : children;

  return (
    <>
      {/* Left icon or spinner */}
      {isLoading ? (
        <Spinner aria-hidden="true" className={cn(size === "icon" && "mx-auto")} />
      ) : (
        leftIcon ? <span aria-hidden="true" className={cn("shrink-0")}>{leftIcon}</span> : null
      )}

      {/* Text (hide when icon-only) */}
      {size === "icon" ? <span className={cn("sr-only")}>{content}</span> : <span className={cn("truncate")}>{content}</span>}

      {/* Right icon */}
      {!isLoading && rightIcon ? (
        <span aria-hidden="true" className={cn("shrink-0")}>{rightIcon}</span>
      ) : null}
    </>
  );
}

function Spinner(
  props: React.SVGProps<SVGSVGElement> & { className?: string },
) {
  const { className, ...rest } = props;
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn("h-4 w-4 animate-spin", className)}
      fill="none"
      {...rest}
    >
      <circle
        className={cn("opacity-25")}
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className={cn("opacity-75")}
        fill="currentColor"
        d="M4 12a8 8 0 018-8v3a5 5 0 00-5 5H4z"
      />
    </svg>
  );
}
