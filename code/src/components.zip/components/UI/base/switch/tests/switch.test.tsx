import { describe, it, expect, vi } from "vitest";
import * as React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { Switch } from "../switch";

describe("Switch", () => {
  it("renders with accessible name (label) and role switch", () => {
    render(<Switch label="Notifications" />);
    expect(screen.getByRole("switch", { name: "Notifications" })).toBeInTheDocument();
  });

  it("calls onCheckedChange when toggled", () => {
    const onCheckedChange = vi.fn();
    render(<Switch label="Notifications" onCheckedChange={onCheckedChange} />);
    const el = screen.getByRole("switch", { name: "Notifications" });
    fireEvent.click(el);
    expect(onCheckedChange).toHaveBeenCalledTimes(1);
  });

  it("does not toggle when disabled", () => {
    const onCheckedChange = vi.fn();
    render(<Switch label="Notifications" disabled onCheckedChange={onCheckedChange} />);
    const el = screen.getByRole("switch", { name: "Notifications" });
    fireEvent.click(el);
    expect(onCheckedChange).not.toHaveBeenCalled();
  });

  it("sets aria-invalid and describes error", () => {
    render(<Switch label="Notifications" error="Required" />);
    const el = screen.getByRole("switch", { name: "Notifications" });
    expect(el).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByText("Required")).toBeInTheDocument();
    expect(el.getAttribute("aria-describedby") ?? "").toContain("error");
  });

  it("supports helper text and description in aria-describedby", () => {
    render(
      <Switch
        label="Notifications"
        description="Emails importants uniquement."
        helperText="Tu peux changer ça plus tard."
      />,
    );
    const el = screen.getByRole("switch", { name: "Notifications" });
    const described = el.getAttribute("aria-describedby") ?? "";
    expect(described).toContain("desc");
    expect(described).toContain("help");
  });
});
