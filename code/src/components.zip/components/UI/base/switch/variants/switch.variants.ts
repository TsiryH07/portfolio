import { cn } from "../../../../utils/cn";
import { UI_DURATIONS, UI_RADII } from "../../../../utils/constants";
import type { SwitchSize } from "../types/switch.types";

export function switchVariants(opts?: {
  uiSize?: SwitchSize;
  hasError?: boolean;
  isDisabled?: boolean;
}) {
  const uiSize = opts?.uiSize ?? "md";

  const sizes: Record<
    SwitchSize,
    { track: string; thumb: string; translate: string; label: string; gap: string }
  > = {
    sm: {
      track: "h-5 w-9",
      thumb: "h-4 w-4",
      translate: "peer-checked:[&>span]:translate-x-4",
      label: "text-sm",
      gap: "gap-2.5",
    },
    md: {
      track: "h-6 w-11",
      thumb: "h-5 w-5",
      translate: "peer-checked:[&>span]:translate-x-5",
      label: "text-sm",
      gap: "gap-3",
    },
    lg: {
      track: "h-7 w-13",
      thumb: "h-6 w-6",
      translate: "peer-checked:[&>span]:translate-x-6",
      label: "text-base",
      gap: "gap-3.5",
    },
  };

  const track = cn(
    "relative inline-flex shrink-0 items-center",
    "border border-slate-200 bg-slate-200 shadow-sm",
    UI_RADII.full,
    "transition-colors",
    UI_DURATIONS.normal,
    "cursor-pointer",
    sizes[uiSize].track,
    sizes[uiSize].translate,
    // On / Off
    "peer-checked:bg-slate-900 peer-checked:border-slate-900",
    // Focus ring
    "peer-focus-visible:ring-2 peer-focus-visible:ring-slate-400 peer-focus-visible:ring-offset-2",
    "peer-focus-visible:border-slate-300",
    // Hover
    "hover:border-slate-300",
    // Disabled
    "peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
    // Error
    opts?.hasError &&
      cn(
        "border-red-500",
        "peer-checked:border-red-600",
        "peer-focus-visible:ring-red-400 peer-focus-visible:border-red-500",
        "hover:border-red-500",
      ),
  );

  const thumb = cn(
    "absolute left-0.5 top-0.5",
    "bg-white",
    "shadow-sm",
    UI_RADII.full,
    "transition-transform",
    UI_DURATIONS.normal,
    sizes[uiSize].thumb,
    // Subtle thumb color change when disabled
    "peer-disabled:bg-slate-100",
  );

  const label = cn(
    "font-medium text-slate-900 leading-snug",
    sizes[uiSize].label,
    opts?.isDisabled && "text-slate-500 cursor-not-allowed",
  );

  const description = cn("text-sm text-slate-600");
  const helper = cn("text-sm text-slate-600");
  const error = cn("text-sm text-red-600");

  const row = cn("flex items-start", sizes[uiSize].gap);

  return { row, track, thumb, label, description, helper, error };
}
