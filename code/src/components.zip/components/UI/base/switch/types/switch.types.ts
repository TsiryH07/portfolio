import type * as React from "react";
import type { Nullable, WithClassName } from "../../../utils/types";

export type SwitchSize = "sm" | "md" | "lg";

export type SwitchIds = Readonly<{
  root: string;
  label: string;
  help: string;
  error: string;
  description: string;
}>;

/**
 * Switch — toggle on/off (préférences)
 *
 * - Base native: <input type="checkbox" role="switch"> (clavier-friendly)
 * - Label/description/helper/error reliés via aria-describedby
 */
export type SwitchProps = WithClassName<
  Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "size"> & {
    uiSize?: SwitchSize;

    label?: React.ReactNode;
    description?: React.ReactNode;
    helperText?: React.ReactNode;
    error?: Nullable<React.ReactNode>;

    /** Callback ergonomique en plus de `onChange`. */
    onCheckedChange?: (checked: boolean) => void;

    /** Classe wrapper externe. */
    containerClassName?: string;

    /** Classe du track (pill). */
    trackClassName?: string;

    /** Classe du thumb. */
    thumbClassName?: string;

    /** Affiche l’astérisque si `required` est true (default true). */
    showRequiredIndicator?: boolean;
  }
>;
