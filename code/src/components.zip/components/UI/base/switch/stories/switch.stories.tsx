import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Switch } from "../switch";

const meta: Meta<typeof Switch> = {
  title: "base/Switch",
  component: Switch,
  args: {
    label: "Enable notifications",
    uiSize: "md",
  },
  argTypes: {
    uiSize: { control: "select", options: ["sm", "md", "lg"] },
    disabled: { control: "boolean" },
    required: { control: "boolean" },
  },
};
export default meta;

type Story = StoryObj<typeof Switch>;

export const Playground: Story = {
  render: (args) => {
    const [checked, setChecked] = React.useState(false);
    return (
      <Switch
        {...args}
        checked={checked}
        onCheckedChange={(v) => setChecked(v)}
        onChange={(e) => args.onChange?.(e)}
      />
    );
  },
};

export const States: Story = {
  parameters: { controls: { disable: true } },
  render: () => (
    <div style={{ display: "grid", gap: 14, maxWidth: 520 }}>
      <Switch label="Off" />
      <Switch label="On" defaultChecked />
      <Switch label="Disabled" disabled />
      <Switch label="Error" error="Required" />
      <Switch
        label="With description"
        description="Only important emails."
        helperText="You can change this later."
        defaultChecked
      />
    </div>
  ),
};

export const Sizes: Story = {
  parameters: { controls: { disable: true } },
  render: () => (
    <div style={{ display: "grid", gap: 14, maxWidth: 520 }}>
      <Switch uiSize="sm" label="Small" />
      <Switch uiSize="md" label="Medium" defaultChecked />
      <Switch uiSize="lg" label="Large" />
    </div>
  ),
};
