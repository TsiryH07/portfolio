import * as React from "react";
import { cn } from "../../../utils/cn";
import { createScopedIds } from "../../../utils/id";
import { switchVariants } from "./variants/switch.variants";
import type { SwitchIds, SwitchProps } from "./types/switch.types";

export const Switch = React.forwardRef<HTMLInputElement, SwitchProps>(function Switch(
  {
    className,
    containerClassName,
    trackClassName,
    thumbClassName,
    uiSize = "md",
    label,
    description,
    helperText,
    error,
    onCheckedChange,
    showRequiredIndicator = true,
    disabled,
    id,
    required,
    onChange,
    "aria-describedby": ariaDescribedByProp,
    role,
    ...rest
  },
  ref,
) {
  const hasError = Boolean(error);
  const isDisabled = Boolean(disabled);

  const ids = React.useMemo<SwitchIds>(() => {
    if (id) {
      const sep = "-";
      return Object.freeze({
        root: id,
        label: `${id}${sep}label`,
        help: `${id}${sep}help`,
        error: `${id}${sep}error`,
        description: `${id}${sep}desc`,
      });
    }
    return createScopedIds("switch");
  }, [id]);

  const describedByIds = [
    ariaDescribedByProp,
    description ? ids.description : null,
    helperText ? ids.help : null,
    hasError ? ids.error : null,
  ]
    .filter(Boolean)
    .join(" ");

  const a11yProps = {
    id: ids.root,
    "aria-invalid": hasError || undefined,
    "aria-describedby": describedByIds.length ? describedByIds : undefined,
  } as const;

  const v = switchVariants({ uiSize, hasError, isDisabled });

  const handleChange: React.ChangeEventHandler<HTMLInputElement> = (e) => {
    if (isDisabled) return;
    onChange?.(e);
    onCheckedChange?.(e.currentTarget.checked);
  };

  return (
    <div className={cn("grid gap-1.5", containerClassName, className)}>
      <div className={cn(v.row)}>
        <input
          ref={ref}
          type="checkbox"
          role={role ?? "switch"}
          disabled={disabled}
          onChange={handleChange}
          className={cn("peer sr-only")}
          required={required}
          {...a11yProps}
          {...rest}
        />

        {/* Track: label sans texte (aria-hidden), clic => toggle */}
        <label
          htmlFor={ids.root}
          aria-hidden="true"
          className={cn(v.track, trackClassName)}
        >
          <span aria-hidden="true" className={cn(v.thumb, thumbClassName)} />
        </label>

        {/* Texte associé (label cliquable) */}
        <div className={cn("min-w-0")}>
          {label ? (
            <label id={ids.label} htmlFor={ids.root} className={cn(v.label)}>
              <span className={cn("align-middle")}>{label}</span>
              {showRequiredIndicator && required ? (
                <span aria-hidden="true" className={cn("ml-1 text-red-600")}>
                  *
                </span>
              ) : null}
            </label>
          ) : null}

          {description ? (
            <div id={ids.description} className={cn(v.description)}>
              {description}
            </div>
          ) : null}
        </div>
      </div>

      {hasError ? (
        <div id={ids.error} className={cn(v.error)}>
          {error}
        </div>
      ) : helperText ? (
        <div id={ids.help} className={cn(v.helper)}>
          {helperText}
        </div>
      ) : null}
    </div>
  );
});

Switch.displayName = "Switch";
