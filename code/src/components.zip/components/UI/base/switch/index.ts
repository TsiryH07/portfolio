export { Switch } from "./switch";
export type { SwitchProps, SwitchSize, SwitchIds } from "./types/switch.types";
export { switchVariants } from "./variants/switch.variants";
