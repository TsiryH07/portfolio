export { Input } from "./input";
export type { InputProps, InputSize, InputIds } from "./types/input.types";
export { inputVariants } from "./variants/input.variants";
