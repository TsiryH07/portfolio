import * as React from "react";
import { cn } from "../../../utils/cn";
import { createScopedIds } from "../../../utils/id";
import { inputVariants } from "./variants/input.variants";
import type { InputIds, InputProps } from "./types/input.types";

export const Input = React.forwardRef<HTMLInputElement, InputProps>(function Input(
  {
    className,
    containerClassName,
    uiSize = "md",
    label,
    description,
    helperText,
    error,
    startIcon,
    endIcon,
    disabled,
    id,
    "aria-describedby": ariaDescribedByProp,
    ...rest
  },
  ref,
) {
  const hasError = Boolean(error);
  const isDisabled = Boolean(disabled);

  const ids = React.useMemo<InputIds>(() => {
    if (id) {
      const sep = "-";
      return Object.freeze({
        root: id,
        label: `${id}${sep}label`,
        help: `${id}${sep}help`,
        error: `${id}${sep}error`,
        description: `${id}${sep}desc`,
      });
    }
    return createScopedIds("field");
  }, [id]);

  const describedByIds = [
    ariaDescribedByProp,
    description ? ids.description : null,
    helperText ? ids.help : null,
    hasError ? ids.error : null,
  ]
    .filter(Boolean)
    .join(" ");

  const a11yProps = {
    id: ids.root,
    "aria-invalid": hasError || undefined,
    "aria-describedby": describedByIds.length ? describedByIds : undefined,
  } as const;

  const v = inputVariants({
    uiSize,
    hasError,
    isDisabled,
    hasStartIcon: Boolean(startIcon),
    hasEndIcon: Boolean(endIcon),
  });

  return (
    <div className={cn("grid gap-1.5", containerClassName)}>
      {label ? (
        <label
          id={ids.label}
          htmlFor={ids.root}
          className={cn("text-sm font-medium text-slate-900")}
        >
          {label}
        </label>
      ) : null}

      {description ? (
        <div id={ids.description} className={cn("text-sm text-slate-600")}>
          {description}
        </div>
      ) : null}

      <div className={cn(v.root)}>
        {startIcon ? <span className={cn(v.startIcon)}>{startIcon}</span> : null}

        <input
          ref={ref}
          disabled={disabled}
          className={cn(v.input, className)}
          {...a11yProps}
          {...rest}
        />

        {endIcon ? <span className={cn(v.endIcon)}>{endIcon}</span> : null}
      </div>

      {hasError ? (
        <div id={ids.error} className={cn("text-sm text-red-600")}>
          {error}
        </div>
      ) : helperText ? (
        <div id={ids.help} className={cn("text-sm text-slate-600")}>
          {helperText}
        </div>
      ) : null}
    </div>
  );
});

Input.displayName = "Input";
