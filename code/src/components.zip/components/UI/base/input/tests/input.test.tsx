import { describe, it, expect } from "vitest";
import * as React from "react";
import { render, screen } from "@testing-library/react";
import { Input } from "../input";

describe("Input", () => {
  it("renders an input", () => {
    render(<Input aria-label="Email" />);
    expect(screen.getByLabelText("Email")).toBeInTheDocument();
  });

  it("renders label and associates it via htmlFor/id", () => {
    render(<Input id="email" label="Email" />);
    const input = screen.getByLabelText("Email") as HTMLInputElement;
    expect(input.id).toBe("email");
    const label = screen.getByText("Email");
    expect(label).toHaveAttribute("for", "email");
  });

  it("wires description + helperText via aria-describedby", () => {
    render(
      <Input
        id="name"
        label="Name"
        description="Public name"
        helperText="This will be shown on your profile"
      />,
    );
    const input = screen.getByLabelText("Name");
    const describedBy = input.getAttribute("aria-describedby") ?? "";
    expect(describedBy).toContain("name-desc");
    expect(describedBy).toContain("name-help");
  });

  it("shows error, sets aria-invalid, and includes error in aria-describedby", () => {
    render(<Input id="pwd" label="Password" error="Required" />);
    const input = screen.getByLabelText("Password");
    expect(input).toHaveAttribute("aria-invalid", "true");
    const describedBy = input.getAttribute("aria-describedby") ?? "";
    expect(describedBy).toContain("pwd-error");
    expect(screen.getByText("Required")).toBeInTheDocument();
  });

  it("disabled input is disabled and styles include disabled expectations", () => {
    render(<Input aria-label="Disabled" disabled />);
    const input = screen.getByLabelText("Disabled") as HTMLInputElement;
    expect(input.disabled).toBe(true);
  });

  it("renders start and end icons", () => {
    render(
      <Input
        aria-label="Search"
        startIcon={<span data-testid="start">S</span>}
        endIcon={<span data-testid="end">E</span>}
      />,
    );
    expect(screen.getByTestId("start")).toBeInTheDocument();
    expect(screen.getByTestId("end")).toBeInTheDocument();
  });
});
