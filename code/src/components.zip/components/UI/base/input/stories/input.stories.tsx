import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Input } from "../input";

const meta: Meta<typeof Input> = {
  title: "base/Input",
  component: Input,
  args: {
    uiSize: "md",
    placeholder: "Type here…",
  },
};
export default meta;

type Story = StoryObj<typeof Input>;

const IconSearch = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="none" {...props}>
    <path
      d="M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15z"
      stroke="currentColor"
      strokeWidth="2"
    />
    <path
      d="M16 16l5 5"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
  </svg>
);

const IconEye = (props: React.SVGProps<SVGSVGElement>) => (
  <svg viewBox="0 0 24 24" fill="none" {...props}>
    <path
      d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
  </svg>
);

export const Playground: Story = {
  render: (args) => <Input {...args} aria-label="Playground" />,
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 12, maxWidth: 420 }}>
      <Input uiSize="sm" label="Small" placeholder="sm" />
      <Input uiSize="md" label="Medium" placeholder="md" />
      <Input uiSize="lg" label="Large" placeholder="lg" />
    </div>
  ),
};

export const WithIcons: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 12, maxWidth: 420 }}>
      <Input
        label="Search"
        placeholder="Search…"
        startIcon={<IconSearch width={18} height={18} />}
      />
      <Input
        label="Password"
        type="password"
        placeholder="••••••••"
        endIcon={<IconEye width={18} height={18} />}
        helperText="You can pass an interactive element as endIcon too."
      />
    </div>
  ),
};

export const States: Story = {
  render: () => (
    <div style={{ display: "grid", gap: 12, maxWidth: 420 }}>
      <Input label="Normal" placeholder="Hello" />
      <Input label="Disabled" placeholder="Can't edit" disabled />
      <Input label="Error" placeholder="Type…" error="This field is required" />
      <Input
        label="Description + helper"
        description="This will be visible to your teammates."
        helperText="Keep it short and clear."
        placeholder="e.g. john.doe"
      />
    </div>
  ),
};
