import { cn } from "../../../../utils/cn";
import { UI_DURATIONS, UI_RADII } from "../../../../utils/constants";
import type { InputSize } from "../types/input.types";

export function inputVariants(opts?: {
  uiSize?: InputSize;
  hasError?: boolean;
  isDisabled?: boolean;
  hasStartIcon?: boolean;
  hasEndIcon?: boolean;
}) {
  const uiSize = opts?.uiSize ?? "md";

  const root = cn(
    "group relative flex items-stretch",
    "border border-slate-200 bg-white shadow-sm",
    UI_RADII.md,
    "transition-colors",
    UI_DURATIONS.normal,
    // Focus ring (clavier / focus)
    "focus-within:ring-2 focus-within:ring-slate-400 focus-within:ring-offset-2",
    "focus-within:border-slate-300",
    // Hover
    "hover:border-slate-300",
    // Disabled
    opts?.isDisabled && "bg-slate-50 text-slate-500 opacity-90",
    // Error
    opts?.hasError &&
      cn(
        "border-red-500",
        "focus-within:ring-red-400 focus-within:border-red-500",
        "hover:border-red-500",
      ),
  );

  const sizes: Record<InputSize, { input: string; icon: string; paddingX: string; height: string }> = {
    sm: {
      height: "h-9",
      paddingX: "px-3",
      input: "text-sm",
      icon: "text-slate-500",
    },
    md: {
      height: "h-10",
      paddingX: "px-3.5",
      input: "text-sm",
      icon: "text-slate-500",
    },
    lg: {
      height: "h-11",
      paddingX: "px-4",
      input: "text-base",
      icon: "text-slate-500",
    },
  };

  const input = cn(
    "min-w-0 flex-1 bg-transparent outline-none",
    "placeholder:text-slate-400",
    "text-slate-900",
    "disabled:cursor-not-allowed",
    sizes[uiSize].height,
    sizes[uiSize].input,
    // padding adjusted if icons exist
    sizes[uiSize].paddingX,
    opts?.hasStartIcon && "pl-0",
    opts?.hasEndIcon && "pr-0",
  );

  const iconBase = cn(
    "inline-flex items-center justify-center",
    "shrink-0",
    sizes[uiSize].height,
    sizes[uiSize].icon,
  );

  const startIcon = cn(iconBase, "pl-3");
  const endIcon = cn(iconBase, "pr-3");

  return {
    root,
    input,
    startIcon,
    endIcon,
  };
}
