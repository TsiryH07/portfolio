import type * as React from "react";
import type { WithClassName, Nullable } from "../../../utils/types";

export type InputSize = "sm" | "md" | "lg";

export type InputIds = Readonly<{
  root: string;
  label: string;
  description: string;
  help: string;
  error: string;
}>;

export type InputProps = WithClassName<
  Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> & {
    /**
     * Taille UI (ne pas confondre avec l’attribut HTML `size`).
     * @default "md"
     */
    uiSize?: InputSize;

    /** Label optionnel (si fourni, le composant rend un <label> associé). */
    label?: React.ReactNode;

    /** Description optionnelle (info supplémentaire, au-dessus du help/error). */
    description?: React.ReactNode;

    /** Texte d’aide (helper text). */
    helperText?: React.ReactNode;

    /**
     * Message d’erreur.
     * - si défini, le champ passe en état error (aria-invalid, styles).
     */
    error?: Nullable<React.ReactNode>;

    /** Icône ou élément à afficher à gauche du champ. */
    startIcon?: React.ReactNode;

    /** Icône ou élément à afficher à droite du champ. */
    endIcon?: React.ReactNode;

    /**
     * ClassName pour le conteneur (wrapper qui inclut label / messages).
     * `className` (WithClassName) est appliqué à l’input lui-même.
     */
    containerClassName?: string;

    /**
     * Permet de forcer des IDs stables (ex: intégration form lib).
     * Si non fourni, des IDs sont générés via utils/id (createScopedIds).
     *
     * Note: l’input utilise `id` (HTML). Les ids dérivés sont : `${id}-label`, `${id}-help`, etc.
     */
    id?: string;
  }
>;
