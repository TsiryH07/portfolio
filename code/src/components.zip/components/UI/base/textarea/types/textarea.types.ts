import type * as React from "react";
import type { WithClassName } from "../../../utils/types";

export type TextareaSize = "sm" | "md" | "lg";
export type TextareaResize = "none" | "y" | "both";

/**
 * IDs a11y générés (label/help/error/description) + count optionnel.
 * Basés sur `createScopedIds("field")`.
 */
export type TextareaIds = Readonly<{
  root: string;
  label: string;
  help: string;
  error: string;
  description: string;
  count: string;
}>;

export type TextareaProps = WithClassName<
  Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "size"> & {
    /** Classe du wrapper externe (grid). */
    containerClassName?: string;

    uiSize?: TextareaSize;

    label?: React.ReactNode;
    description?: React.ReactNode;
    helperText?: React.ReactNode;

    /** Message d'erreur (active hasError + aria-invalid). */
    error?: React.ReactNode | null;

    /** Contrôle le resize CSS. */
    resize?: TextareaResize;

    /**
     * Affiche un compteur de caractères.
     * Si `maxLength` est fourni, on affiche "X / maxLength".
     */
    showCount?: boolean;
  }
>;
