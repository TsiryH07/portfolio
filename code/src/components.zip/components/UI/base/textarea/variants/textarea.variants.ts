import { cn } from "../../../../utils/cn";
import { UI_DURATIONS, UI_RADII } from "../../../../utils/constants";
import type { TextareaResize, TextareaSize } from "../types/textarea.types";

export function textareaVariants(opts?: {
  uiSize?: TextareaSize;
  resize?: TextareaResize;
  hasError?: boolean;
  isDisabled?: boolean;
}) {
  const uiSize = opts?.uiSize ?? "md";
  const resize = opts?.resize ?? "y";

  const root = cn(
    "group relative flex",
    "border border-slate-200 bg-white shadow-sm",
    UI_RADII.md,
    "transition-colors",
    UI_DURATIONS.normal,
    // Focus ring (clavier / focus)
    "focus-within:ring-2 focus-within:ring-slate-400 focus-within:ring-offset-2",
    "focus-within:border-slate-300",
    // Hover
    "hover:border-slate-300",
    // Disabled
    opts?.isDisabled && "bg-slate-50 text-slate-500 opacity-90",
    // Error
    opts?.hasError &&
      cn(
        "border-red-500",
        "focus-within:ring-red-400 focus-within:border-red-500",
        "hover:border-red-500",
      ),
  );

  const sizes: Record<TextareaSize, { padding: string; text: string; minHeight: string }> = {
    sm: { padding: "px-3 py-2", text: "text-sm", minHeight: "min-h-20" },
    md: { padding: "px-3.5 py-2.5", text: "text-sm", minHeight: "min-h-24" },
    lg: { padding: "px-4 py-3", text: "text-base", minHeight: "min-h-28" },
  };

  const resizeClass: Record<TextareaResize, string> = {
    none: "resize-none",
    y: "resize-y",
    both: "resize",
  };

  const textarea = cn(
    "min-w-0 flex-1 bg-transparent outline-none",
    "placeholder:text-slate-400",
    "text-slate-900",
    "disabled:cursor-not-allowed",
    sizes[uiSize].padding,
    sizes[uiSize].text,
    sizes[uiSize].minHeight,
    resizeClass[resize],
  );

  return { root, textarea };
}
