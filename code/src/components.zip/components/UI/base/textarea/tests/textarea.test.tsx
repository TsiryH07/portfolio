import { describe, it, expect } from "vitest";
import * as React from "react";
import { render, screen } from "@testing-library/react";
import { Textarea } from "../textarea";

describe("Textarea", () => {
  it("renders a textarea", () => {
    render(<Textarea placeholder="Type..." />);
    expect(screen.getByPlaceholderText("Type...")).toBeInTheDocument();
  });

  it("links label to textarea via htmlFor/id", () => {
    render(<Textarea label="Message" />);
    // getByLabelText relies on label -> textarea association
    expect(screen.getByLabelText("Message")).toBeInTheDocument();
  });

  it("sets aria-describedby with description and helperText", () => {
    render(
      <Textarea
        label="Notes"
        description="Short description"
        helperText="Helper"
        aria-describedby="external"
      />,
    );
    const el = screen.getByLabelText("Notes");
    const desc = screen.getByText("Short description");
    const help = screen.getByText("Helper");
    const described = el.getAttribute("aria-describedby") ?? "";
    expect(described).toContain("external");
    expect(described).toContain(desc.id);
    expect(described).toContain(help.id);
  });

  it("shows error state and aria-invalid", () => {
    render(<Textarea label="Bio" error="Required" />);
    const el = screen.getByLabelText("Bio");
    expect(el).toHaveAttribute("aria-invalid", "true");
    expect(screen.getByText("Required")).toBeInTheDocument();
  });

  it("respects disabled state", () => {
    render(<Textarea label="Bio" disabled />);
    const el = screen.getByLabelText("Bio");
    expect(el).toBeDisabled();
  });

  it("shows character count when enabled", () => {
    render(<Textarea label="Bio" showCount maxLength={100} value="hello" />);
    expect(screen.getByText(/5\s*\/\s*100/)).toBeInTheDocument();
  });
});
