import * as React from "react";
import { cn } from "../../../utils/cn";
import { createScopedIds } from "../../../utils/id";
import { formatNumber } from "../../../utils/format";
import { textareaVariants } from "./variants/textarea.variants";
import type { TextareaIds, TextareaProps } from "./types/textarea.types";

function getValueLength(value: unknown): number {
  if (typeof value === "string") return value.length;
  if (typeof value === "number") return String(value).length;
  return 0;
}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  {
    className,
    containerClassName,
    uiSize = "md",
    resize = "y",
    label,
    description,
    helperText,
    error,
    showCount,
    disabled,
    id,
    maxLength,
    value,
    defaultValue,
    "aria-describedby": ariaDescribedByProp,
    ...rest
  },
  ref,
) {
  const hasError = Boolean(error);
  const isDisabled = Boolean(disabled);

  const ids = React.useMemo<TextareaIds>(() => {
    const base =
      id ??
      // createScopedIds already returns {root,label,help,error,description}
      createScopedIds("field").root;

    const sep = "-";
    const rootId = base;

    return Object.freeze({
      root: rootId,
      label: `${rootId}${sep}label`,
      help: `${rootId}${sep}help`,
      error: `${rootId}${sep}error`,
      description: `${rootId}${sep}desc`,
      count: `${rootId}${sep}count`,
    });
  }, [id]);

  const shouldShowCount = Boolean(showCount || typeof maxLength === "number");

  const describedByIds = [
    ariaDescribedByProp,
    description ? ids.description : null,
    helperText ? ids.help : null,
    hasError ? ids.error : null,
    shouldShowCount ? ids.count : null,
  ]
    .filter(Boolean)
    .join(" ");

  const a11yProps = {
    id: ids.root,
    "aria-invalid": hasError || undefined,
    "aria-describedby": describedByIds.length ? describedByIds : undefined,
  } as const;

  const v = textareaVariants({
    uiSize,
    resize,
    hasError,
    isDisabled,
  });

  const currentLen =
    typeof value !== "undefined"
      ? getValueLength(value)
      : typeof defaultValue !== "undefined"
        ? getValueLength(defaultValue)
        : 0;

  return (
    <div className={cn("grid gap-1.5", containerClassName)}>
      {label ? (
        <label
          id={ids.label}
          htmlFor={ids.root}
          className={cn("text-sm font-medium text-slate-900")}
        >
          {label}
        </label>
      ) : null}

      {description ? (
        <div id={ids.description} className={cn("text-sm text-slate-600")}>
          {description}
        </div>
      ) : null}

      <div className={cn(v.root)}>
        <textarea
          ref={ref}
          disabled={disabled}
          maxLength={maxLength}
          value={value as any}
          defaultValue={defaultValue as any}
          className={cn(v.textarea, className)}
          {...a11yProps}
          {...rest}
        />
      </div>

      {(hasError || helperText || shouldShowCount) ? (
        <div className={cn("flex items-start justify-between gap-3")}>
          {hasError ? (
            <div id={ids.error} className={cn("text-sm text-red-600")}>
              {error}
            </div>
          ) : helperText ? (
            <div id={ids.help} className={cn("text-sm text-slate-600")}>
              {helperText}
            </div>
          ) : (
            <div />
          )}

          {shouldShowCount ? (
            <div
              id={ids.count}
              className={cn(
                "text-xs text-slate-500 tabular-nums",
                hasError && "text-red-600/80",
              )}
            >
              {typeof maxLength === "number"
                ? `${formatNumber(currentLen)} / ${formatNumber(maxLength)}`
                : formatNumber(currentLen)}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
});

Textarea.displayName = "Textarea";
