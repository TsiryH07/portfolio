export { Textarea } from "./textarea";
export type {
  TextareaProps,
  TextareaIds,
  TextareaSize,
  TextareaResize,
} from "./types/textarea.types";
export { textareaVariants } from "./variants/textarea.variants";
