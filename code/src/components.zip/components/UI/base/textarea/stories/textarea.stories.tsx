import type { Meta, StoryObj } from "@storybook/react";
import * as React from "react";
import { Textarea } from "../textarea";

const meta: Meta<typeof Textarea> = {
  title: "base/Textarea",
  component: Textarea,
  parameters: { layout: "padded" },
  args: {
    label: "Message",
    placeholder: "Ecris quelque chose",
    uiSize: "md",
  },
};
export default meta;

type Story = StoryObj<typeof Textarea>;

const StoryGrid = ({ children }: { children: React.ReactNode }) => (
  <div style={{ display: "grid", gap: 20, maxWidth: 720 }}>{children}</div>
);

const Section = ({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) => (
  <div style={{ display: "grid", gap: 8 }}>
    <div style={{ display: "grid", gap: 2 }}>
      <span style={{ fontWeight: 600 }}>{title}</span>
      {description ? <span style={{ color: "#475569", fontSize: 14 }}>{description}</span> : null}
    </div>
    <div style={{ display: "grid", gap: 12 }}>{children}</div>
  </div>
);

export const Playground: Story = {};

export const Sizes: Story = {
  render: () => (
    <StoryGrid>
      <Section title="Tailles" description="Adapte la densite selon l'espace et l'importance.">
        <Textarea label="Small" uiSize="sm" placeholder="Texte concis" />
        <Textarea label="Medium" uiSize="md" placeholder="Valeur par defaut" />
        <Textarea label="Large" uiSize="lg" placeholder="Espace pour des notes detaillees" />
      </Section>
    </StoryGrid>
  ),
};

export const States: Story = {
  render: () => (
    <StoryGrid>
      <Section title="Normal" description="Texte libre avec aide contextuelle.">
        <Textarea label="Normal" helperText="Texte d'aide" placeholder="Normal..." />
      </Section>

      <Section title="Desactive" description="Affiche le contenu mais bloque la saisie.">
        <Textarea label="Disabled" disabled defaultValue="Lecture seule" />
      </Section>

      <Section title="Erreur" description="Rends l'etat d'erreur explicite.">
        <Textarea
          label="Error"
          error="Ce champ est requis."
          defaultValue="Valeur non valide"
          showCount
          maxLength={120}
        />
      </Section>

      <Section title="Avec description" description="Ajoute du contexte avant la saisie.">
        <Textarea
          label="Brief"
          description="Decris le contexte pour aider la lecture."
          placeholder="Entre ton message"
        />
      </Section>
    </StoryGrid>
  ),
};

export const ResizeModes: Story = {
  render: () => (
    <StoryGrid>
      <Section
        title="Modes de redimensionnement"
        description="Controle la maniere dont l'utilisateur peut redimensionner."
      >
        <Textarea label="resize-none" resize="none" placeholder="Pas de resize" style={{ minHeight: 90 }} />
        <Textarea label="resize-y" resize="y" placeholder="Resize vertical" style={{ minHeight: 90 }} />
        <Textarea label="resize-both" resize="both" placeholder="Resize libre" style={{ minHeight: 90 }} />
      </Section>
    </StoryGrid>
  ),
};

export const WithCount: Story = {
  render: () => {
    const [value, setValue] = React.useState("");
    return (
      <StoryGrid>
        <Section
          title="Compteur libre"
          description="Affiche le nombre de caracteres saisis quand showCount est active."
        >
          <Textarea
            label="Notes"
            helperText="Garde ca court."
            value={value}
            onChange={(e) => setValue(e.target.value)}
            showCount
            placeholder="Saisie controlee"
          />
        </Section>

        <Section
          title="Compteur et limite"
          description="maxLength ajoute un compteur et bloque la saisie au dela."
        >
          <Textarea
            label="Message limite"
            description="Limite a 180 caracteres."
            maxLength={180}
            showCount
            placeholder="Ajoute du texte jusqu'a la limite"
            defaultValue="Exemple avec limite."
          />
        </Section>
      </StoryGrid>
    );
  },
};
