import { describe, expect, it } from "vitest";
import { assertDefined, assertNever, assertNonEmptyString, invariant, InvariantError } from "../assert";

describe("assert utils", () => {
  it("invariant ne throw pas si condition truthy", () => {
    expect(() => invariant(true, "ok")).not.toThrow();
  });

  it("invariant throw si condition falsy", () => {
    expect(() => invariant(false, "User must exist")).toThrow(InvariantError);
  });

  it("assertDefined narrow + throw si null", () => {
    const v: string | null = "x";
    expect(() => assertDefined(v)).not.toThrow();
    // runtime (null)
    expect(() => assertDefined(null as any, "Value required")).toThrow(InvariantError);
  });

  it("assertNonEmptyString", () => {
    expect(() => assertNonEmptyString("hello")).not.toThrow();
    expect(() => assertNonEmptyString("   ")).toThrow(InvariantError);
    expect(() => assertNonEmptyString(123 as any)).toThrow(InvariantError);
  });

  it("assertNever always throws", () => {
    expect(() => assertNever("x" as never)).toThrow(InvariantError);
  });

  it("custom errorFactory works", () => {
    class MyErr extends Error {}
    expect(() =>
      invariant(false, "boom", {
        errorFactory: (m) => new MyErr(m),
      }),
    ).toThrow(MyErr);
  });
});
