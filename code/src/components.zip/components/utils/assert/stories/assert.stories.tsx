  "use client";

  import React from "react";
  import type { Meta, StoryObj } from "@storybook/react";
  import { assertDefined, assertNonEmptyString, invariant } from "../assert";

  function Pill({ children }: { children: React.ReactNode }) {
    return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{children}</span>;
  }

  class Boundary extends React.Component<{ children: React.ReactNode }, { error: Error | null }> {
    state = { error: null as Error | null };
    static getDerivedStateFromError(error: Error) {
      return { error };
    }
    componentDidCatch() {}
    reset = () => this.setState({ error: null });
    render() {
      if (this.state.error) {
        return (
          <div className="rounded-2xl border border-rose-200 bg-rose-50 p-6 text-rose-900 space-y-3">
            <div className="text-sm font-semibold">Erreur capturée</div>
            <div className="font-mono text-sm break-words">{this.state.error.name}: {this.state.error.message}</div>
            <button
              type="button"
              onClick={this.reset}
              className="rounded-xl border border-rose-200 bg-white px-3 py-2 text-sm hover:bg-rose-100 transition"
            >
              Reset
            </button>
          </div>
        );
      }
      return <>{this.props.children}</>;
    }
  }

  function AssertDemo() {
    const [userExists, setUserExists] = React.useState(true);
    const [name, setName] = React.useState("Mina");
    const [value, setValue] = React.useState("42");

    function runInvariant() {
      invariant(userExists, "User must exist");
      alert("✅ invariant OK");
    }

    function runDefined() {
      const v: string | null = value === "null" ? null : value;
      assertDefined(v, "Value must be defined");
      alert("✅ assertDefined OK: " + v);
    }

    function runNonEmpty() {
      assertNonEmptyString(name, "Name must be non-empty");
      alert("✅ assertNonEmptyString OK: " + name);
    }

    return (
      <div className="p-6 space-y-6">
        <header className="space-y-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold">assert — garde-fous (invariants)</h2>
              <p className="text-sm text-slate-600">
                Objectif : éviter les bugs silencieux et obtenir des erreurs claires (surtout en dev).
              </p>
            </div>
            <Pill>utils/assert</Pill>
          </div>
        </header>

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <h3 className="font-semibold">Tester</h3>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">invariant(userExists)</label>
              <label className="inline-flex items-center gap-2 text-sm rounded-xl border border-slate-200 bg-white px-3 py-2">
                <input type="checkbox" checked={userExists} onChange={(e) => setUserExists(e.target.checked)} />
                userExists = {String(userExists)}
              </label>
              <button
                type="button"
                onClick={runInvariant}
                className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm font-medium hover:opacity-90 transition"
              >
                Run invariant
              </button>
            </div>

            <div className="h-px bg-slate-100" />

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">assertDefined(value)</label>
              <input
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder='Tape "null" pour casser'
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-300"
              />
              <button
                type="button"
                onClick={runDefined}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50 transition"
              >
                Run assertDefined
              </button>
            </div>

            <div className="h-px bg-slate-100" />

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">assertNonEmptyString(name)</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder='Vide / espaces pour casser'
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-300"
              />
              <button
                type="button"
                onClick={runNonEmpty}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50 transition"
              >
                Run assertNonEmptyString
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 space-y-3">
            <h3 className="font-semibold">Patterns</h3>
            <pre className="text-xs overflow-auto rounded-xl bg-slate-950 text-slate-50 p-4">
              <code>{`import { invariant, assertDefined } from "@/components/utils/assert";

invariant(user, "User must exist");
assertDefined(user.profile, "Profile required");

// switch exhaustif
switch (status) {
  case "idle": ...
  case "loading": ...
  case "success": ...
  case "error": ...
  default: assertNever(status);
}`}</code>
            </pre>
            <div className="text-xs text-slate-500">
              Dans Storybook, une Error Boundary capture les erreurs pour éviter de casser la page.
            </div>
          </div>
        </div>
      </div>
    );
  }

  function Wrapped() {
    return (
      <Boundary>
        <AssertDemo />
      </Boundary>
    );
  }

  const meta: Meta<typeof Wrapped> = {
    title: "utils/assert",
    component: Wrapped,
    parameters: { layout: "fullscreen" },
  };

  export default meta;
  type Story = StoryObj<typeof Wrapped>;
  export const Default: Story = {};
