/**
 * assert — garde-fous (invariants) pour éviter les bugs silencieux.
 *
 * Exemples:
 *   invariant(user, "User must exist");
 *   assertDefined(value, "Value required");
 *   assertNever(x);
 *
 * Objectif:
 * - erreurs claires en dev
 * - base stable pour production (messages optionnels)
 */

export type AssertEnv = "development" | "production";

function getEnv(): AssertEnv {
  const env = (globalThis as any)?.process?.env?.NODE_ENV;
  return env === "development" ? "development" : "production";
}

export const isDev = getEnv() === "development";

export class InvariantError extends Error {
  name = "InvariantError";
  constructor(message?: string) {
    super(message ?? "Invariant failed");
  }
}

export type InvariantOptions = {
  /**
   * Message en production (si tu veux éviter d'exposer des détails).
   * Par défaut: "Invariant failed".
   */
  productionMessage?: string;
  /** Fournir une factory d'erreur custom. */
  errorFactory?: (message: string) => Error;
};

function buildMessage(devMessage: string | undefined, opts?: InvariantOptions): string {
  if (isDev) return devMessage ?? "Invariant failed";
  return opts?.productionMessage ?? "Invariant failed";
}

/**
 * invariant — throw si condition falsy.
 * - TypeScript: `asserts condition` => narrowing.
 */
export function invariant(condition: unknown, devMessage?: string, opts?: InvariantOptions): asserts condition {
  if (condition) return;

  const message = buildMessage(devMessage, opts);
  const err = opts?.errorFactory ? opts.errorFactory(message) : new InvariantError(message);
  throw err;
}

/**
 * assertDefined — vérifie non-null/non-undefined
 */
export function assertDefined<T>(value: T, devMessage?: string, opts?: InvariantOptions): asserts value is NonNullable<T> {
  invariant(value !== null && value !== undefined, devMessage ?? "Value must be defined", opts);
}

/**
 * assertNonEmptyString — vérifie string non vide (trim).
 */
export function assertNonEmptyString(value: unknown, devMessage?: string, opts?: InvariantOptions): asserts value is string {
  invariant(typeof value === "string" && value.trim().length > 0, devMessage ?? "String must be non-empty", opts);
}

/**
 * assertNever — utile pour exhaustive checks (switch).
 */
export function assertNever(x: never, devMessage?: string, opts?: InvariantOptions): never {
  invariant(false, devMessage ?? `Unexpected value: ${String(x)}`, opts);
  // unreachable
  throw new InvariantError("Unreachable");
}

/**
 * unreachable — alias plus lisible.
 */
export function unreachable(devMessage?: string, opts?: InvariantOptions): never {
  invariant(false, devMessage ?? "Unreachable code path", opts);
  throw new InvariantError("Unreachable");
}
