import type { InvariantOptions } from "../assert";

/**
 * Presets : standardiser le comportement app-wide.
 */
export const assertPresets = Object.freeze({
  /** En prod, message neutre. */
  safeProd: {
    productionMessage: "Unexpected error",
  } satisfies InvariantOptions,

  /** En prod, message un peu plus explicite (sans détails). */
  prodInvariant: {
    productionMessage: "Invariant failed",
  } satisfies InvariantOptions,
} as const);
