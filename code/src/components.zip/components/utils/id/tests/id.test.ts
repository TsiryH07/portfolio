import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { createId, createIdFactory, createScopedIds } from "../id";

describe("id utils", () => {
  const originalCryptoDescriptor = Object.getOwnPropertyDescriptor(globalThis, "crypto");

  const setCrypto = (value: any) =>
    Object.defineProperty(globalThis, "crypto", { value, configurable: true, writable: true });

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  afterEach(() => {
    if (originalCryptoDescriptor) {
      Object.defineProperty(globalThis, "crypto", originalCryptoDescriptor);
    } else {
      delete (globalThis as any).crypto;
    }
    vi.unstubAllGlobals();
  });

  it("ajoute le prefix si fourni", () => {
    const id = createId({ prefix: "field" });
    expect(id.startsWith("field_")).toBe(true);
  });

  it("createIdFactory préconfigure un prefix", () => {
    const make = createIdFactory({ prefix: "toast" });
    const id = make();
    expect(id.startsWith("toast_")).toBe(true);
  });

  it("createScopedIds produit des ids liés", () => {
    const ids = createScopedIds("email");
    expect(ids.root).toContain("email-");
    expect(ids.label).toContain("label");
    expect(ids.help).toContain("help");
  });

  it("utilise crypto.randomUUID si dispo", () => {
    setCrypto({
      randomUUID: () => "123e4567-e89b-12d3-a456-426614174000",
    });
    const id = createId({ prefix: "ui" });
    expect(id).toBe("ui_123e4567e89b12d3a456426614174000");
  });

  it("fallback getRandomValues si randomUUID absent", () => {
    setCrypto({
      getRandomValues: (arr: Uint8Array) => {
        // Remplit avec une valeur stable
        for (let i = 0; i < arr.length; i++) arr[i] = 1;
        return arr;
      },
    });
    const id = createId({ prefix: "ui" });
    expect(id.startsWith("ui_")).toBe(true);
    // base62 mapping of 1 => "1"
    expect(id).toBe("ui_" + "1".repeat(12));
  });

  it("génère des ids uniques (probabiliste)", () => {
    const a = createId();
    const b = createId();
    expect(a).not.toBe(b);
  });

  it("separator custom", () => {
    const id = createId({ prefix: "field", separator: "-" });
    expect(id.startsWith("field-")).toBe(true);
  });
});
