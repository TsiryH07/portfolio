"use client";

import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { createId, createScopedIds, isStrongIdAvailable } from "../id";
import { idFactories } from "../variants/id.variants";

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{children}</span>;
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = React.useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 900);
        } catch {
          // ignore
        }
      }}
      className="text-xs rounded-lg border border-slate-200 bg-white px-2 py-1 hover:bg-slate-50 transition"
    >
      {copied ? "Copié" : "Copier"}
    </button>
  );
}

function IdCard({ title, id }: { title: string; id: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="text-sm font-medium text-slate-900">{title}</div>
        <div className="font-mono text-xs text-slate-600 break-all">{id}</div>
      </div>
      <CopyButton value={id} />
    </div>
  );
}

function IdDemo() {
  // Good practice: generate once (not per render)
  const rootId = React.useMemo(() => createId({ prefix: "ui" }), []);
  const aria = React.useMemo(() => createScopedIds("email"), []);

  const [items, setItems] = React.useState(() => [
    { id: createId({ prefix: "item" }), label: "Premier item" },
    { id: createId({ prefix: "item" }), label: "Deuxième item" },
  ]);

  const [optimistic, setOptimistic] = React.useState<{ id: string; label: string } | null>(null);

  async function addOptimistic() {
    const tmp = { id: idFactories.optimistic(), label: "Optimistic item" };
    setOptimistic(tmp);

    // simule un server response
    await new Promise((r) => setTimeout(r, 600));

    // server renvoie un id "stable"
    const stable = { id: createId({ prefix: "item" }), label: "Item confirmé" };
    setItems((prev) => [stable, ...prev]);
    setOptimistic(null);
  }

  return (
    <div className="p-6 space-y-6">
      <header className="space-y-2">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">id — IDs uniques (UI)</h2>
            <p className="text-sm text-slate-600">
              Pour keys stables, aria-* et optimistic UI. <span className="font-mono">crypto</span>{" "}
              {isStrongIdAvailable() ? "✅ dispo" : "⚠️ fallback"}.
            </p>
          </div>
          <Pill>utils/id</Pill>
        </div>
      </header>

      <section className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-semibold">IDs générés</h3>
            <Pill>generate once</Pill>
          </div>
          <div className="space-y-2">
            <IdCard title="createId({ prefix: 'ui' })" id={rootId} />
            <IdCard title="createScopedIds('email').help" id={aria.help} />
            <IdCard title="createScopedIds('email').error" id={aria.error} />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
          <h3 className="font-semibold">Exemple aria-describedby</h3>

          <div className="space-y-2">
            <label htmlFor={aria.root} id={aria.label} className="text-sm font-medium text-slate-900">
              Email
            </label>
            <input
              id={aria.root}
              aria-labelledby={aria.label}
              aria-describedby={aria.help}
              placeholder="name@company.com"
              className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-300"
            />
            <div id={aria.help} className="text-xs text-slate-500">
              Nous n'utilisons ton email que pour te notifier.
            </div>
          </div>

          <div className="h-px bg-slate-100" />

          <div className="space-y-2">
            <div className="text-sm font-medium text-slate-900">List keys + optimistic UI</div>
            <button
              type="button"
              onClick={addOptimistic}
              className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm font-medium hover:opacity-90 transition"
            >
              Add optimistic item
            </button>

            <div className="space-y-2 pt-2">
              {optimistic ? (
                <div className="rounded-xl border border-slate-200 bg-amber-50 px-3 py-2 text-sm">
                  <span className="font-mono text-xs text-slate-600">{optimistic.id}</span>{" "}
                  <span className="text-slate-900">— {optimistic.label}</span>
                </div>
              ) : null}

              {items.map((it) => (
                <div key={it.id} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm">
                  <span className="font-mono text-xs text-slate-600">{it.id}</span>{" "}
                  <span className="text-slate-900">— {it.label}</span>
                </div>
              ))}
            </div>

            <div className="text-xs text-slate-500">
              Conseil : pour un composant, génère l'id une seule fois (useMemo/useRef), pas à chaque render.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

const meta: Meta<typeof IdDemo> = {
  title: "utils/id",
  component: IdDemo,
  parameters: { layout: "fullscreen" },
};

export default meta;
type Story = StoryObj<typeof IdDemo>;
export const Default: Story = {};
