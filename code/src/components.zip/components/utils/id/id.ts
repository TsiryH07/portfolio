/**
 * id — générer des IDs uniques (createId())
 *
 * Objectif :
 * - keys stables (ex: listes)
 * - ids pour aria (aria-describedby, aria-labelledby, etc.)
 * - identifiants client pour optimistic UI
 *
 * Notes importantes (React) :
 * - Ne génère PAS un id à chaque render. Fais-le une seule fois (useRef/useMemo).
 * - Pour des ids liés au rendu SSR/hydration, React 18 propose aussi `useId()`.
 */

export type IdOptions = {
  /** Prefix (ex: "ui", "toast", "field") => "ui_xxx" */
  prefix?: string;
  /** Séparateur entre prefix et la partie random. Par défaut "_" */
  separator?: string;
};

export type IdFactory = (opts?: IdOptions) => string;

// ---------------------------------------------------------------------------
// Internal
// ---------------------------------------------------------------------------

const DEFAULT_SEPARATOR = "_";

function hasCrypto(): boolean {
  return typeof globalThis !== "undefined" && typeof (globalThis as any).crypto !== "undefined";
}

function hasRandomUUID(): boolean {
  return hasCrypto() && typeof (globalThis as any).crypto.randomUUID === "function";
}

function hasGetRandomValues(): boolean {
  return hasCrypto() && typeof (globalThis as any).crypto.getRandomValues === "function";
}

/** Base62 compact (URL-safe, lisible) */
const ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

function bytesToBase62(bytes: Uint8Array): string {
  // Convertit un buffer en string base62 (simple & stable).
  // Ce n'est pas une "vraie" base62 mathématique parfaite, mais pour IDs c'est OK:
  // on mappe chaque byte vers un char.
  let out = "";
  for (let i = 0; i < bytes.length; i++) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out;
}

function fallbackRandomPart(): string {
  // 12 chars => assez pour UI ids (risque collision très faible).
  if (hasGetRandomValues()) {
    const bytes = new Uint8Array(12);
    (globalThis as any).crypto.getRandomValues(bytes);
    return bytesToBase62(bytes);
  }

  // Dernier recours (environnements très limités)
  // combine time + counter + random => réduit collisions.
  const t = Date.now().toString(36);
  const r = Math.random().toString(36).slice(2, 10);
  const c = nextCounter().toString(36);
  return `${t}${c}${r}`;
}

let __counter = 0;
function nextCounter(): number {
  __counter = (__counter + 1) % 1_000_000;
  return __counter;
}

function join(prefix: string | undefined, sep: string, id: string): string {
  if (!prefix) return id;
  const cleaned = prefix.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9_-]/g, "");
  return cleaned ? `${cleaned}${sep}${id}` : id;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * createId — génère un ID unique.
 *
 * Stratégie :
 * - prefer `crypto.randomUUID()` si dispo (le plus robuste)
 * - sinon `crypto.getRandomValues()` (base62)
 * - sinon fallback timestamp + counter + Math.random
 */
export function createId(opts: IdOptions = {}): string {
  const sep = opts.separator ?? DEFAULT_SEPARATOR;

  if (hasRandomUUID()) {
    const uuid = (globalThis as any).crypto.randomUUID() as string;
    // uuid contient des "-" => ok pour HTML id, mais on le compacte un peu
    const compact = uuid.replace(/-/g, "");
    return join(opts.prefix, sep, compact);
  }

  return join(opts.prefix, sep, fallbackRandomPart());
}

/**
 * createIdFactory — utile pour créer une fonction pré-configurée (prefix commun).
 *
 * Exemple:
 *   const fieldId = createIdFactory({ prefix: "field" });
 *   const id = fieldId(); // field_xxx
 */
export function createIdFactory(defaults: IdOptions = {}): IdFactory {
  return (opts: IdOptions = {}) => createId({ ...defaults, ...opts });
}

/**
 * createScopedIds — génère un mini "bundle" d'ids liés à un scope (ex: aria).
 *
 * Exemple:
 *   const ids = createScopedIds("email");
 *   // ids.root, ids.label, ids.help, ids.error
 */
export function createScopedIds(scope: string, opts: Omit<IdOptions, "prefix"> = {}) {
  const base = createId({ prefix: scope, separator: opts.separator ?? "-" });
  const sep = opts.separator ?? "-";

  return Object.freeze({
    root: base,
    label: `${base}${sep}label`,
    help: `${base}${sep}help`,
    error: `${base}${sep}error`,
    description: `${base}${sep}desc`,
  });
}

/**
 * isStrongIdAvailable — info utile (debug) : crypto UUID ou randomValues.
 */
export function isStrongIdAvailable(): boolean {
  return hasRandomUUID() || hasGetRandomValues();
}
