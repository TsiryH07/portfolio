import { createIdFactory } from "../id";

/**
 * Presets de factories pour uniformiser dans l'app.
 */
export const idFactories = Object.freeze({
  ui: createIdFactory({ prefix: "ui" }),
  field: createIdFactory({ prefix: "field" }),
  toast: createIdFactory({ prefix: "toast" }),
  optimistic: createIdFactory({ prefix: "tmp" }),
} as const);
