import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { copy } from "../copy";

describe("copy()", () => {
  const originalClipboard = (navigator as any).clipboard;
  const originalIsSecureContext = (globalThis as any).isSecureContext;
  const originalExec = document.execCommand;

  beforeEach(() => {
    (globalThis as any).isSecureContext = true;
    (navigator as any).clipboard = { writeText: vi.fn().mockResolvedValue(undefined) };
    document.execCommand = vi.fn().mockReturnValue(true) as any;
  });

  afterEach(() => {
    (navigator as any).clipboard = originalClipboard;
    (globalThis as any).isSecureContext = originalIsSecureContext;
    document.execCommand = originalExec;
    vi.restoreAllMocks();
  });

  it("copie via navigator.clipboard quand possible", async () => {
    const res = await copy("hello");
    expect(res.ok).toBe(true);
    if (res.ok) expect(res.method).toBe("navigator");
    expect((navigator as any).clipboard.writeText).toHaveBeenCalledWith("hello");
  });

  it("fallback si navigator échoue", async () => {
    (navigator as any).clipboard.writeText = vi.fn().mockRejectedValue(new Error("nope"));
    const res = await copy("hello", { fallback: true });
    expect(res.ok).toBe(true);
    if (res.ok) expect(res.method).toBe("fallback");
    expect(document.execCommand).toHaveBeenCalledWith("copy");
  });

  it("retourne PERMISSION_DENIED si navigator échoue et fallback=false", async () => {
    const err = Object.assign(new Error("denied"), { name: "NotAllowedError" });
    (navigator as any).clipboard.writeText = vi.fn().mockRejectedValue(err);

    const res = await copy("hello", { fallback: false });
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.error.code).toBe("PERMISSION_DENIED");
  });

  it("force le fallback si forceFallback=true", async () => {
    const res = await copy("hello", { forceFallback: true });
    expect(res.ok).toBe(true);
    if (res.ok) expect(res.method).toBe("fallback");
    expect(document.execCommand).toHaveBeenCalledWith("copy");
  });

  it("EMPTY si string vide (par défaut)", async () => {
    const res = await copy("");
    expect(res.ok).toBe(false);
    if (!res.ok) expect(res.error.code).toBe("EMPTY");
  });

  it("autorise string vide si allowEmpty=true", async () => {
    const res = await copy("", { allowEmpty: true, forceFallback: true });
    expect(res.ok).toBe(true);
  });

  it("UNSUPPORTED si pas de fallback et pas de clipboard API", async () => {
    (navigator as any).clipboard = undefined;
    document.execCommand = undefined as any;

    const res = await copy("hello", { preferNavigator: true, fallback: true });
    expect(res.ok).toBe(false);
    if (!res.ok) expect(["FAILED", "UNSUPPORTED"]).toContain(res.error.code);
  });
});
