  "use client";

  import React from "react";
  import type { Meta, StoryObj } from "@storybook/react";
  import { copy, getCopyMessage } from "../copy";
  import { copyMessages } from "../variants/copy.variants";

  function Pill({ children }: { children: React.ReactNode }) {
    return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{children}</span>;
  }

  function Toast({ kind, children }: { kind: "success" | "error"; children: React.ReactNode }) {
    return (
      <div
        role="status"
        className={
          "rounded-2xl border p-3 text-sm shadow-sm " +
          (kind === "success" ? "border-emerald-200 bg-emerald-50 text-emerald-900" : "border-rose-200 bg-rose-50 text-rose-900")
        }
      >
        {children}
      </div>
    );
  }

  function CopyDemo() {
    const [value, setValue] = React.useState("https://example.com/invite/ABC-123");
    const [forceFallback, setForceFallback] = React.useState(false);
    const [noFallback, setNoFallback] = React.useState(false);
    const [status, setStatus] = React.useState<{ kind: "success" | "error"; message: string } | null>(null);

    async function onCopy() {
      setStatus(null);
      const res = await copy(value, {
        forceFallback,
        fallback: !noFallback,
        preferNavigator: true,
      });

      const message = getCopyMessage(res, copyMessages);
      if (res.ok) {
        setStatus({ kind: "success", message: `${message} (méthode: ${res.method})` });
      } else {
        setStatus({ kind: "error", message: `${message} (code: ${res.error.code})` });
      }

      // auto-dismiss
      window.setTimeout(() => setStatus(null), 2200);
    }

    return (
      <div className="p-6 space-y-6">
        <header className="space-y-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold">copy — presse-papier fiable</h2>
              <p className="text-sm text-slate-600">
                Utilise <code>navigator.clipboard</code> quand possible, sinon fallback <code>execCommand</code>.
              </p>
            </div>
            <Pill>utils/copy</Pill>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-sm">
            <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
              <input type="checkbox" checked={forceFallback} onChange={(e) => setForceFallback(e.target.checked)} />
              Force fallback
            </label>
            <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
              <input type="checkbox" checked={noFallback} onChange={(e) => setNoFallback(e.target.checked)} />
              Désactiver fallback
            </label>
          </div>
        </header>

        <section className="grid lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
            <h3 className="font-semibold">Essayer</h3>
            <p className="text-sm text-slate-600">Tape un texte/URL puis copie.</p>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">Texte à copier</label>
              <div className="flex gap-2">
                <input
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-300"
                />
                <button
                  type="button"
                  onClick={onCopy}
                  className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm font-medium hover:opacity-90 transition"
                >
                  Copier
                </button>
              </div>
              <div className="text-xs text-slate-500">
                Astuce : active “Force fallback” pour simuler un environnement où <code>navigator.clipboard</code> échoue.
              </div>
            </div>

            {status ? <Toast kind={status.kind}>{status.message}</Toast> : null}
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 space-y-3">
            <h3 className="font-semibold">Pourquoi ce helper</h3>
            <ul className="list-disc pl-5 text-sm text-slate-700 space-y-1">
              <li>HTTPS / permissions / iframes : <code>navigator.clipboard</code> peut être bloqué.</li>
              <li>Fallback “ancien” : <code>execCommand('copy')</code> marche encore dans beaucoup de cas.</li>
              <li>API stable : pas de <code>console.log</code> ni de try/catch partout.</li>
            </ul>

            <pre className="text-xs overflow-auto rounded-xl bg-slate-950 text-slate-50 p-4">
              <code>{`import { copy } from "@/components/utils/copy";

const res = await copy("Hello");
if (res.ok) {
  // res.method: "navigator" | "fallback"
} else {
  // res.error.code + message
}`}</code>
            </pre>
          </div>
        </section>
      </div>
    );
  }

  const meta: Meta<typeof CopyDemo> = {
    title: "utils/copy",
    component: CopyDemo,
    parameters: { layout: "fullscreen" },
  };

  export default meta;
  type Story = StoryObj<typeof CopyDemo>;
  export const Default: Story = {};
