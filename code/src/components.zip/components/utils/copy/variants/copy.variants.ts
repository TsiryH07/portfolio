import type { CopyOptions } from "../copy";

/**
 * Presets cohérents pour l'app (DX).
 * - default: navigator + fallback
 * - fallbackOnly: utile dans certains environnements (iframes, etc.)
 */
export const copyPresets = Object.freeze({
  default: { preferNavigator: true, fallback: true } satisfies CopyOptions,
  fallbackOnly: { preferNavigator: false, fallback: true } satisfies CopyOptions,
  noFallback: { preferNavigator: true, fallback: false } satisfies CopyOptions,
} as const);

export const copyMessages = Object.freeze({
  SUCCESS: "Copié ✅",
  EMPTY: "Rien à copier.",
  UNSUPPORTED: "Copie indisponible ici.",
  PERMISSION_DENIED: "Permission presse-papier refusée.",
  FAILED: "La copie a échoué. Réessaie.",
} as const);
