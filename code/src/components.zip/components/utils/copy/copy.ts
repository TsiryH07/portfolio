/**
 * copy — helper "copier dans le presse-papier" avec fallback.
 *
 * Pourquoi :
 * - navigator.clipboard ne marche pas toujours (HTTPS / permissions / iframe / browser policies).
 * - On fournit un fallback `document.execCommand('copy')` + erreurs propres.
 *
 * ⚠️ Utilitaire UI : pas de logique métier.
 */

export type CopyMethod = "navigator" | "fallback";

export type CopyErrorCode =
  | "EMPTY"
  | "UNSUPPORTED"
  | "PERMISSION_DENIED"
  | "FAILED";

export type CopyError = {
  code: CopyErrorCode;
  message: string;
  cause?: unknown;
};

export type CopyResult =
  | { ok: true; method: CopyMethod }
  | { ok: false; error: CopyError };

export type CopyOptions = {
  /** Si false, on n'essaie pas navigator.clipboard (direct fallback). */
  preferNavigator?: boolean;
  /** Force le fallback (utile pour démo/tests). */
  forceFallback?: boolean;
  /** Autorise la copie de string vide. Par défaut: false. */
  allowEmpty?: boolean;
  /**
   * Si true, on tente le fallback si navigator.clipboard échoue.
   * Par défaut: true.
   */
  fallback?: boolean;
};

const DEFAULT_ERROR_MESSAGES: Record<CopyErrorCode, string> = {
  EMPTY: "Rien à copier.",
  UNSUPPORTED: "Copie impossible sur ce navigateur / contexte.",
  PERMISSION_DENIED: "Permission refusée pour accéder au presse-papier.",
  FAILED: "La copie a échoué. Réessaie.",
};

function error(code: CopyErrorCode, cause?: unknown, message?: string): CopyResult {
  return {
    ok: false,
    error: {
      code,
      message: message ?? DEFAULT_ERROR_MESSAGES[code],
      ...(cause !== undefined ? { cause } : {}),
    },
  };
}

function hasDom(): boolean {
  return typeof window !== "undefined" && typeof document !== "undefined";
}

function canUseNavigatorClipboard(): boolean {
  if (!hasDom()) return false;
  const nav = navigator as any;
  const hasApi = Boolean(nav?.clipboard?.writeText);
  // `isSecureContext` est true sur HTTPS / localhost. Sur HTTP -> false => souvent interdit.
  const secure = (globalThis as any).isSecureContext !== false;
  return hasApi && secure;
}

async function copyWithNavigator(text: string): Promise<boolean> {
  const nav = navigator as any;
  await nav.clipboard.writeText(text);
  return true;
}

function copyWithFallback(text: string): boolean {
  if (!hasDom()) return false;
  if (typeof document.execCommand !== "function") return false;

  const textarea = document.createElement("textarea");
  textarea.value = text;

  // Evite zoom iOS + scroll jump
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.top = "0";
  textarea.style.left = "0";
  textarea.style.opacity = "0";
  textarea.style.pointerEvents = "none";
  textarea.style.width = "1px";
  textarea.style.height = "1px";

  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();

  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch {
    ok = false;
  } finally {
    textarea.remove();
  }
  return ok;
}

/**
 * copy — copie du texte dans le presse-papier, avec fallback.
 */
export async function copy(text: string, opts: CopyOptions = {}): Promise<CopyResult> {
  const allowEmpty = opts.allowEmpty ?? false;
  if (!allowEmpty && (!text || text.trim().length === 0)) return error("EMPTY");

  if (!hasDom()) return error("UNSUPPORTED");

  const preferNavigator = opts.preferNavigator ?? true;
  const fallbackEnabled = opts.fallback ?? true;
  const forceFallback = opts.forceFallback ?? false;

  // 1) navigator.clipboard
  if (preferNavigator && !forceFallback && canUseNavigatorClipboard()) {
    try {
      await copyWithNavigator(text);
      return { ok: true, method: "navigator" };
    } catch (e: any) {
      // Permission / policy
      if (!fallbackEnabled) {
        const name = String(e?.name ?? "");
        if (name === "NotAllowedError" || name === "SecurityError") {
          return error("PERMISSION_DENIED", e);
        }
        return error("FAILED", e);
      }
      // sinon on tente fallback
    }
  }

  // 2) fallback
  if (fallbackEnabled) {
    const ok = copyWithFallback(text);
    if (ok) return { ok: true, method: "fallback" };
  }

  // 3) échec
  // Si on arrive ici après une tentative navigator, on ne sait pas toujours si c'est permission ou autre
  if (preferNavigator && canUseNavigatorClipboard()) return error("PERMISSION_DENIED");
  return error("FAILED");
}

/**
 * Petit helper utile pour l'UI : transforme un résultat en message user-friendly.
 */
export function getCopyMessage(result: CopyResult, messages?: Partial<Record<CopyErrorCode | "SUCCESS", string>>): string {
  if (result.ok) return messages?.SUCCESS ?? "Copié ✅";
  return messages?.[result.error.code] ?? result.error.message;
}
