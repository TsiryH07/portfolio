import { describe, expect, it } from "vitest";
import { formatBytes, formatCurrency, formatDate, formatDateTime, formatNumber, formatPercent, truncate } from "../format";

describe("format utils", () => {
  it("formatDate retourne — si invalid", () => {
    expect(formatDate(null)).toBe("—");
    expect(formatDate("not-a-date")).toBe("—");
  });

  it("formatDate est stable avec UTC", () => {
    // 2025-01-02 UTC
    const d = new Date("2025-01-02T00:00:00.000Z");
    expect(formatDate(d, { locale: "en-US", timeZone: "UTC", dateStyle: "medium" })).toBe("Jan 2, 2025");
  });

  it("formatDateTime ajoute l'heure", () => {
    const d = new Date("2025-01-02T13:45:00.000Z");
    // Avec timeZone UTC, en-US, short time => 1:45 PM
    expect(formatDateTime(d, { locale: "en-US", timeZone: "UTC", dateStyle: "medium" })).toContain("2025");
  });

  it("formatNumber", () => {
    expect(formatNumber(1234.567, { locale: "en-US", maximumFractionDigits: 1 })).toBe("1,234.6");
    expect(formatNumber(undefined)).toBe("—");
  });

  it("formatCurrency", () => {
    // en-US stable: $1,234.50
    expect(formatCurrency(1234.5, { locale: "en-US", currency: "USD", minimumFractionDigits: 2 })).toBe("$1,234.50");
  });

  it("formatPercent", () => {
    expect(formatPercent(0.42, { locale: "en-US", maximumFractionDigits: 0, inputIsRatio: true })).toBe("42%");
    expect(formatPercent(42, { locale: "en-US", maximumFractionDigits: 0, inputIsRatio: false })).toBe("42%");
  });

  it("truncate", () => {
    expect(truncate("hello", { max: 10 })).toBe("hello");
    expect(truncate("hello world", { max: 8 })).toBe("hello…");
    expect(truncate("hello world", { max: 8, preserveWords: true })).toBe("hello…");
  });

  it("formatBytes", () => {
    expect(formatBytes(0)).toBe("0 B");
    expect(formatBytes(1024, { locale: "en-US", base: 1024 })).toBe("1 KiB");
    expect(formatBytes(1500, { locale: "en-US", base: 1000 })).toBe("1.5 kB");
  });
});
