import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import {
  formatBytes,
  formatCurrency,
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercent,
  truncate,
} from "../format";
import { formatPresets } from "../variants/format.variants";

function Code({ children }: { children: string }) {
  return (
    <pre className="text-xs overflow-auto rounded-xl bg-slate-950 text-slate-50 p-4">
      <code>{children}</code>
    </pre>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm space-y-2">
      <div className="text-sm font-medium text-slate-900">{label}</div>
      {children}
    </div>
  );
}

function FormatDemo() {
  const [locale, setLocale] = React.useState("fr-FR");
  const [currency, setCurrency] = React.useState("EUR");

  const date = "2025-01-02T13:45:00.000Z";
  const amount = 1234.5;
  const number = 9876543.21;
  const percent = 0.427;
  const bytes = 5_242_880; // 5 MiB
  const text = "Un dashboard lisible commence par des formats cohérents partout.";

  const dateOut = formatDate(date, { ...formatPresets.dateMedium, locale });
  const dateTimeOut = formatDateTime(date, { ...formatPresets.dateTime, locale });
  const curOut = formatCurrency(amount, { locale, currency });
  const numOut = formatNumber(number, { locale, ...formatPresets.numberCompact });
  const pctOut = formatPercent(percent, { locale, ...formatPresets.percent1 });
  const bytesOut = formatBytes(bytes, { locale, decimals: 1, base: 1024 });
  const truncOut = truncate(text, { max: 38, preserveWords: true });

  return (
    <div className="p-6 space-y-6">
      <header className="space-y-2">
        <h2 className="text-lg font-semibold">format — présentation uniformisée</h2>
        <p className="text-sm text-slate-600">
          Functions “UI only” basées sur <code>Intl</code> (pas de logique métier).
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <label className="text-sm text-slate-700 flex items-center gap-2">
            Locale
            <select
              value={locale}
              onChange={(e) => setLocale(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
            >
              <option value="fr-FR">fr-FR</option>
              <option value="en-US">en-US</option>
              <option value="de-DE">de-DE</option>
              <option value="mg-MG">mg-MG</option>
            </select>
          </label>

          <label className="text-sm text-slate-700 flex items-center gap-2">
            Currency
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"
            >
              <option value="EUR">EUR</option>
              <option value="USD">USD</option>
              <option value="MGA">MGA</option>
            </select>
          </label>
        </div>
      </header>

      <div className="grid lg:grid-cols-2 gap-6">
        <Field label="formatDate (UTC)">
          <div className="text-2xl font-semibold tracking-tight">{dateOut}</div>
          <Code>{`formatDate("${date}", { locale: "${locale}", dateStyle: "medium", timeZone: "UTC" })`}</Code>
        </Field>

        <Field label="formatDateTime (UTC)">
          <div className="text-2xl font-semibold tracking-tight">{dateTimeOut}</div>
          <Code>{`formatDateTime("${date}", { locale: "${locale}", dateStyle: "medium", timeStyle: "short", timeZone: "UTC" })`}</Code>
        </Field>

        <Field label="formatCurrency">
          <div className="text-2xl font-semibold tracking-tight">{curOut}</div>
          <Code>{`formatCurrency(${amount}, { locale: "${locale}", currency: "${currency}" })`}</Code>
        </Field>

        <Field label="formatNumber (compact)">
          <div className="text-2xl font-semibold tracking-tight">{numOut}</div>
          <Code>{`formatNumber(${number}, { locale: "${locale}", notation: "compact", maximumFractionDigits: 1 })`}</Code>
        </Field>

        <Field label="formatPercent">
          <div className="text-2xl font-semibold tracking-tight">{pctOut}</div>
          <Code>{`formatPercent(${percent}, { locale: "${locale}", maximumFractionDigits: 1, inputIsRatio: true })`}</Code>
        </Field>

        <Field label="formatBytes">
          <div className="text-2xl font-semibold tracking-tight">{bytesOut}</div>
          <Code>{`formatBytes(${bytes}, { locale: "${locale}", base: 1024, decimals: 1 })`}</Code>
        </Field>

        <Field label="truncate (preserveWords)">
          <div className="text-lg text-slate-900">{truncOut}</div>
          <Code>{`truncate("${text}", { max: 38, preserveWords: true })`}</Code>
        </Field>
      </div>
    </div>
  );
}

const meta: Meta<typeof FormatDemo> = {
  title: "utils/format",
  component: FormatDemo,
  parameters: { layout: "fullscreen" },
};

export default meta;
type Story = StoryObj<typeof FormatDemo>;
export const Default: Story = {};
