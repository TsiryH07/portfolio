/**
 * Presets de formatage (cohérence UI).
 * Tu peux les utiliser dans tables/dashboards sans re-taper les options.
 */
import type { FormatCurrencyOptions, FormatDateOptions, FormatNumberOptions, FormatPercentOptions } from "../format";

export const formatPresets = Object.freeze({
  dateShort: { dateStyle: "short", timeZone: "UTC" } satisfies FormatDateOptions,
  dateMedium: { dateStyle: "medium", timeZone: "UTC" } satisfies FormatDateOptions,
  dateTime: { dateStyle: "medium", timeStyle: "short", timeZone: "UTC" } satisfies FormatDateOptions,

  numberCompact: { notation: "compact", maximumFractionDigits: 1 } satisfies FormatNumberOptions,
  numberInt: { maximumFractionDigits: 0 } satisfies FormatNumberOptions,

  currencyEur: { currency: "EUR", currencyDisplay: "symbol" } satisfies FormatCurrencyOptions,
  currencyUsd: { currency: "USD", currencyDisplay: "symbol" } satisfies FormatCurrencyOptions,

  percent0: { maximumFractionDigits: 0, inputIsRatio: true } satisfies FormatPercentOptions,
  percent1: { maximumFractionDigits: 1, inputIsRatio: true } satisfies FormatPercentOptions,
} as const);
