/**
 * format — fonctions de formatage présentation (UI)
 *
 * Objectif : uniformiser l’affichage (dashboard, tables, pages, etc)
 * sans logique métier (uniquement présentation).
 */

export type Locale = string;

// ---------------------------------------------------------------------------
// Date
// ---------------------------------------------------------------------------

export type FormatDateStyle = "short" | "medium" | "long" | "full";
export type FormatDateTimeZone = string; // IANA tz, ex: "UTC", "Europe/Paris"

export type FormatDateOptions = {
  locale?: Locale;
  /** Par défaut : "UTC" pour éviter les surprises en test/SSR */
  timeZone?: FormatDateTimeZone;
  dateStyle?: FormatDateStyle;
  timeStyle?: FormatDateStyle;
};

/**
 * formatDate — formatte une date (Date | timestamp | string ISO).
 */
export function formatDate(
  value: Date | string | number | null | undefined,
  opts: FormatDateOptions = {},
): string {
  if (value === null || value === undefined || value === "") return "—";

  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "—";

  const locale = opts.locale ?? "fr-FR";
  const timeZone = opts.timeZone ?? "UTC";

  const formatter = new Intl.DateTimeFormat(locale, {
    timeZone,
    dateStyle: opts.dateStyle ?? "medium",
    ...(opts.timeStyle ? { timeStyle: opts.timeStyle } : {}),
  });

  return formatter.format(date);
}

/**
 * formatDateTime — alias pratique pour date+heure.
 */
export function formatDateTime(
  value: Date | string | number | null | undefined,
  opts: Omit<FormatDateOptions, "timeStyle"> & { timeStyle?: FormatDateStyle } = {},
): string {
  return formatDate(value, { ...opts, timeStyle: opts.timeStyle ?? "short" });
}

// ---------------------------------------------------------------------------
// Number / Currency / Percent
// ---------------------------------------------------------------------------

export type FormatNumberOptions = {
  locale?: Locale;
  maximumFractionDigits?: number;
  minimumFractionDigits?: number;
  notation?: "standard" | "compact" | "scientific" | "engineering";
  signDisplay?: "auto" | "never" | "always" | "exceptZero";
};

export function formatNumber(
  value: number | null | undefined,
  opts: FormatNumberOptions = {},
): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";

  const locale = opts.locale ?? "fr-FR";
  const formatter = new Intl.NumberFormat(locale, {
    maximumFractionDigits: opts.maximumFractionDigits ?? 2,
    ...(opts.minimumFractionDigits !== undefined ? { minimumFractionDigits: opts.minimumFractionDigits } : {}),
    ...(opts.notation ? { notation: opts.notation } : {}),
    ...(opts.signDisplay ? { signDisplay: opts.signDisplay } : {}),
  });

  return formatter.format(value);
}

export type FormatCurrencyOptions = Omit<FormatNumberOptions, "maximumFractionDigits" | "minimumFractionDigits"> & {
  currency?: string; // ex: "EUR", "USD", "MGA"
  /** Par défaut : 2 */
  maximumFractionDigits?: number;
  minimumFractionDigits?: number;
  currencyDisplay?: "symbol" | "narrowSymbol" | "code" | "name";
};

export function formatCurrency(
  value: number | null | undefined,
  opts: FormatCurrencyOptions = {},
): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";

  const locale = opts.locale ?? "fr-FR";
  const currency = opts.currency ?? "EUR";

  const formatter = new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    maximumFractionDigits: opts.maximumFractionDigits ?? 2,
    ...(opts.minimumFractionDigits !== undefined ? { minimumFractionDigits: opts.minimumFractionDigits } : {}),
    ...(opts.currencyDisplay ? { currencyDisplay: opts.currencyDisplay } : {}),
    ...(opts.notation ? { notation: opts.notation } : {}),
    ...(opts.signDisplay ? { signDisplay: opts.signDisplay } : {}),
  });

  return formatter.format(value);
}

export type FormatPercentOptions = FormatNumberOptions & {
  /** true => value=0.42 -> 42% ; false => value=42 -> 42% */
  inputIsRatio?: boolean;
};

export function formatPercent(
  value: number | null | undefined,
  opts: FormatPercentOptions = {},
): string {
  if (value === null || value === undefined || Number.isNaN(value)) return "—";

  const locale = opts.locale ?? "fr-FR";
  const inputIsRatio = opts.inputIsRatio ?? true;
  const normalized = inputIsRatio ? value : value / 100;

  const formatter = new Intl.NumberFormat(locale, {
    style: "percent",
    maximumFractionDigits: opts.maximumFractionDigits ?? 0,
    ...(opts.minimumFractionDigits !== undefined ? { minimumFractionDigits: opts.minimumFractionDigits } : {}),
    ...(opts.notation ? { notation: opts.notation } : {}),
    ...(opts.signDisplay ? { signDisplay: opts.signDisplay } : {}),
  });

  return formatter.format(normalized);
}

// ---------------------------------------------------------------------------
// Text helpers
// ---------------------------------------------------------------------------

export type TruncateOptions = {
  max?: number;
  /** ellipsis par défaut */
  suffix?: string;
  /** conserve les mots (coupe au dernier espace) */
  preserveWords?: boolean;
};

export function truncate(value: string | null | undefined, opts: TruncateOptions = {}): string {
  if (value === null || value === undefined) return "—";
  const s = String(value);
  const max = opts.max ?? 32;
  const suffix = opts.suffix ?? "…";
  const preserveWords = opts.preserveWords ?? true;
  if (s.length <= max) return s;

  const cut = max - suffix.length;
  if (cut <= 0) return suffix.slice(0, max);

  const sliced = s.slice(0, cut);
  if (!preserveWords) return sliced + suffix;

  const lastSpace = sliced.lastIndexOf(" ");
  if (lastSpace <= 0) return sliced + suffix;
  return sliced.slice(0, lastSpace) + suffix;
}

export type FormatBytesOptions = {
  locale?: Locale;
  decimals?: number;
  /**
   * Base 1024 (KiB/MiB/GiB) ou 1000 (kB/MB/GB).
   * Par défaut : 1024 (souvent attendu côté dev).
   */
  base?: 1000 | 1024;
};

/**
 * formatBytes — affiche des octets en format humain (ex: 1.5 MB).
 */
export function formatBytes(bytes: number | null | undefined, opts: FormatBytesOptions = {}): string {
  if (bytes === null || bytes === undefined || Number.isNaN(bytes)) return "—";
  const locale = opts.locale ?? "fr-FR";
  const base = opts.base ?? 1024;
  const decimals = opts.decimals ?? 1;

  if (bytes < 0) return "—";
  if (bytes === 0) return "0 B";

  const units = base === 1024
    ? ["B", "KiB", "MiB", "GiB", "TiB"]
    : ["B", "kB", "MB", "GB", "TB"];

  let v = bytes;
  let i = 0;
  while (v >= base && i < units.length - 1) {
    v /= base;
    i += 1;
  }

  const n = new Intl.NumberFormat(locale, {
    maximumFractionDigits: decimals,
    minimumFractionDigits: 0,
  }).format(v);

  return `${n} ${units[i]}`;
}
