import { describe, expect, it, vi } from "vitest";
import { sleep, withMinimumDelay, SleepAbortedError } from "../sleep";

describe("sleep", () => {
  it("attend ms (fake timers)", async () => {
    vi.useFakeTimers();
    const p = sleep(500);
    let done = false;
    p.then(() => (done = true));

    await vi.advanceTimersByTimeAsync(499);
    expect(done).toBe(false); // reste 1ms

    await vi.advanceTimersByTimeAsync(1);
    expect(done).toBe(true);

    vi.useRealTimers();
  });

  it("ms négatif => 0", async () => {
    vi.useFakeTimers();
    const p = sleep(-10);
    await vi.runAllTimersAsync();
    await expect(p).resolves.toBeUndefined();
    vi.useRealTimers();
  });

  it("abort => reject par défaut", async () => {
    vi.useFakeTimers();
    const controller = new AbortController();
    const p = sleep(1000, { signal: controller.signal });
    controller.abort();
    vi.runAllTimers();
    await expect(p).rejects.toBeInstanceOf(SleepAbortedError);
    vi.useRealTimers();
  });

  it("abort => resolve si resolveOnAbort=true", async () => {
    vi.useFakeTimers();
    const controller = new AbortController();
    const p = sleep(1000, { signal: controller.signal, resolveOnAbort: true });
    controller.abort();
    vi.runAllTimers();
    await expect(p).resolves.toBeUndefined();
    vi.useRealTimers();
  });

  it("withMinimumDelay garantit un min", async () => {
    vi.useFakeTimers();

    const fast = Promise.resolve("ok");
    const p = withMinimumDelay(fast, 400);

    // avant 400ms, pas résolu
    let resolved = false;
    p.then(() => (resolved = true));

    await vi.advanceTimersByTimeAsync(399);
    expect(resolved).toBe(false);

    await vi.advanceTimersByTimeAsync(1);
    expect(resolved).toBe(true);

    vi.useRealTimers();
  });
});
