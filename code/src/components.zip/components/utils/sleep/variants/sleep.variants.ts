import { ANIMATION_MS } from "../../utils/constants"; // optionnel si constants existe dans ton projet
import type { SleepOptions } from "../sleep";

/**
 * Presets de delay pour UX (cohérence).
 * Si tu n'as pas `constants`, remplace par des nombres.
 */
export const sleepPresets = Object.freeze({
  micro: 120,
  short: 180,
  normal: 260,
  overlay: 320,
} as const);

export const sleepOptionsPresets = Object.freeze({
  default: {} satisfies SleepOptions,
  resolveOnAbort: { resolveOnAbort: true } satisfies SleepOptions,
} as const);

// Note: On n'exporte pas directement ANIMATION_MS ici car ça dépend de ton setup.
