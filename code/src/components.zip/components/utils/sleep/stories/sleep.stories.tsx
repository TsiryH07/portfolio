  "use client";

  import React from "react";
  import type { Meta, StoryObj } from "@storybook/react";
  import { sleep, withMinimumDelay } from "../sleep";

  function Pill({ children }: { children: React.ReactNode }) {
    return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{children}</span>;
  }

  function SleepDemo() {
    const [ms, setMs] = React.useState(500);
    const [loading, setLoading] = React.useState(false);
    const [message, setMessage] = React.useState<string | null>(null);

    async function runSleep() {
      setMessage(null);
      setLoading(true);
      const t0 = performance.now();
      await sleep(ms);
      const t1 = performance.now();
      setLoading(false);
      setMessage(`✅ Terminé en ~${Math.round(t1 - t0)}ms`);
    }

    async function runMinDelay() {
      setMessage(null);
      setLoading(true);
      const t0 = performance.now();

      // Simule une requête très rapide (ex: cache)
      const data = await withMinimumDelay(Promise.resolve("ok"), ms);

      const t1 = performance.now();
      setLoading(false);
      setMessage(`✅ Promise "${data}" mais durée min respectée: ~${Math.round(t1 - t0)}ms`);
    }

    return (
      <div className="p-6 space-y-6">
        <header className="space-y-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold">sleep — attendre X ms</h2>
              <p className="text-sm text-slate-600">
                Utile pour simuler des loadings / laisser respirer l'UX (toast, transitions…).
              </p>
            </div>
            <Pill>utils/sleep</Pill>
          </div>
        </header>

        <section className="grid lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-900">Durée (ms)</label>
              <input
                type="range"
                min={0}
                max={2000}
                step={50}
                value={ms}
                onChange={(e) => setMs(parseInt(e.target.value, 10))}
                className="w-full"
              />
              <div className="flex items-center justify-between text-xs text-slate-600">
                <span>0</span>
                <span className="font-mono">{ms}ms</span>
                <span>2000</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={runSleep}
                disabled={loading}
                className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
              >
                await sleep(ms)
              </button>

              <button
                type="button"
                onClick={runMinDelay}
                disabled={loading}
                className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium hover:bg-slate-50 transition disabled:opacity-50"
              >
                withMinimumDelay()
              </button>
            </div>

            {loading ? (
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                <div className="flex items-center gap-3">
                  <div className="h-4 w-4 rounded-full border-2 border-slate-300 border-t-slate-900 animate-spin" />
                  <span>Loading… (simulation)</span>
                </div>
              </div>
            ) : null}

            {message ? (
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">
                {message}
              </div>
            ) : (
              <div className="text-xs text-slate-500">
                Tip : <code>withMinimumDelay</code> évite un spinner “flash” trop rapide.
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 space-y-3">
            <h3 className="font-semibold">Exemples</h3>
            <pre className="text-xs overflow-auto rounded-xl bg-slate-950 text-slate-50 p-4">
              <code>{`// 1) Simuler un loading
setLoading(true);
await sleep(500);
setLoading(false);

// 2) Laisser un toast respirer avant redirect
toast("Saved");
await sleep(300);
router.push("/dashboard");

// 3) Eviter un flash (min delay)
const data = await withMinimumDelay(fetchData(), 450);`}</code>
            </pre>
          </div>
        </section>
      </div>
    );
  }

  const meta: Meta<typeof SleepDemo> = {
    title: "utils/sleep",
    component: SleepDemo,
    parameters: { layout: "fullscreen" },
  };

  export default meta;
  type Story = StoryObj<typeof SleepDemo>;
  export const Default: Story = {};
