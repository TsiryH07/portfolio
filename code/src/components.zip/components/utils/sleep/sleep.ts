/**
 * sleep — attendre X ms (await sleep(500))
 *
 * Pourquoi :
 * - tests manuels
 * - simulateurs de loading
 * - UX (laisser un toast 300ms avant redirect, etc.)
 */

export type SleepOptions = {
  /** Permet d'annuler le sleep (AbortController). */
  signal?: AbortSignal;
  /** Si true, le sleep résout quand même si abort (au lieu de throw). */
  resolveOnAbort?: boolean;
};

export class SleepAbortedError extends Error {
  name = "SleepAbortedError";
  constructor(message = "Sleep aborted") {
    super(message);
  }
}

/**
 * sleep — Promise qui résout après `ms`.
 * - Compatible AbortSignal : abort => reject par défaut
 */
export function sleep(ms: number, options: SleepOptions = {}): Promise<void> {
  const { signal, resolveOnAbort } = options;

  // Normalisation : ms négatif => 0
  const duration = Number.isFinite(ms) ? Math.max(0, Math.floor(ms)) : 0;

  if (signal?.aborted) {
    return resolveOnAbort ? Promise.resolve() : Promise.reject(new SleepAbortedError());
  }

  return new Promise<void>((resolve, reject) => {
    const id = window.setTimeout(() => {
      cleanup();
      resolve();
    }, duration);

    const onAbort = () => {
      cleanup();
      if (resolveOnAbort) resolve();
      else reject(new SleepAbortedError());
    };

    function cleanup() {
      window.clearTimeout(id);
      signal?.removeEventListener("abort", onAbort);
    }

    if (signal) signal.addEventListener("abort", onAbort, { once: true });
  });
}

/**
 * withMinimumDelay — UX helper :
 * Garantit que la promesse prend au moins `minMs` (évite un "flash" trop rapide).
 *
 * Exemple :
 *   setLoading(true)
 *   const data = await withMinimumDelay(fetchData(), 450)
 *   setLoading(false)
 */
export async function withMinimumDelay<T>(promise: Promise<T>, minMs: number): Promise<T> {
  const duration = Number.isFinite(minMs) ? Math.max(0, Math.floor(minMs)) : 0;
  const [res] = await Promise.all([promise, sleep(duration)]);
  return res;
}
