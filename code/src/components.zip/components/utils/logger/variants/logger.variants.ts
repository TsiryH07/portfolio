import type { LoggerOptions, LogLevel } from "../logger";

/**
 * Presets pour standardiser le comportement dans l'app.
 * Exemple :
 *   export const appLogger = createLogger(loggerPresets.prodQuiet);
 */
export const loggerPresets = Object.freeze({
  devVerbose: {
    enabled: true,
    level: "debug" satisfies LogLevel,
    pretty: true,
  } satisfies LoggerOptions,

  prodQuiet: {
    enabled: true,
    level: "warn" satisfies LogLevel,
    pretty: false,
  } satisfies LoggerOptions,

  prodOff: {
    enabled: false,
    level: "silent" satisfies LogLevel,
    pretty: false,
  } satisfies LoggerOptions,
} as const);
