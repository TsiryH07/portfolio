import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { createLogger } from "../logger";
import type { LogEvent, LogLevel } from "../logger";

function pill(text: string) {
  return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{text}</span>;
}

function levelColor(level: LogLevel) {
  switch (level) {
    case "debug":
      return "text-slate-600";
    case "info":
      return "text-slate-900";
    case "warn":
      return "text-amber-700";
    case "error":
      return "text-rose-700";
    default:
      return "text-slate-500";
  }
}

function LogRow({ e }: { e: LogEvent }) {
  return (
    <div className="flex gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2">
      <div className="w-16 font-mono text-xs text-slate-500">{e.time.toISOString().slice(11, 19)}</div>
      <div className={"w-16 font-mono text-xs " + levelColor(e.level)}>{e.level.toUpperCase()}</div>
      <div className="min-w-0 flex-1">
        <div className="text-sm text-slate-900">
          {e.scope ? <span className="text-slate-500">[{e.scope}] </span> : null}
          {e.message}
        </div>
        {e.meta?.length ? (
          <pre className="mt-1 text-xs overflow-auto rounded-lg bg-slate-950 text-slate-50 p-3">
            {JSON.stringify(e.meta, null, 2)}
          </pre>
        ) : null}
      </div>
    </div>
  );
}

function LoggerDemo() {
  const [enabled, setEnabled] = React.useState(true);
  const [level, setLevel] = React.useState<LogLevel>("debug");
  const [scope, setScope] = React.useState("ui");
  const [events, setEvents] = React.useState<LogEvent[]>([]);

  const transport = React.useCallback((e: LogEvent) => {
    setEvents((prev) => [e, ...prev].slice(0, 50));
  }, []);

  const log = React.useMemo(() => {
    return createLogger({
      enabled,
      level,
      pretty: true,
      scope,
      transports: [
        transport,
        // On garde aussi la console pour dev DX, tu peux l'enlever si besoin
        (e) => {
          // eslint-disable-next-line no-console
          const fn =
            e.level === "debug"
              ? console.debug
              : e.level === "info"
                ? console.info
                : e.level === "warn"
                  ? console.warn
                  : console.error;
          fn(`[${e.scope ?? "app"}] ${e.message}`, ...(e.meta ?? []));
        },
      ],
    });
  }, [enabled, level, scope, transport]);

  return (
    <div className="p-6 space-y-6">
      <header className="space-y-2">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">logger — logs propres & contrôlés</h2>
            <p className="text-sm text-slate-600">
              Remplace les <code>console.log</code> dispersés par une API stable (dev lisible, prod configurable).
            </p>
          </div>
          {pill("utils/logger")}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-sm">
          <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            enabled
          </label>

          <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
            level
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value as LogLevel)}
              className="rounded-lg border border-slate-200 bg-white px-2 py-1"
            >
              <option value="debug">debug</option>
              <option value="info">info</option>
              <option value="warn">warn</option>
              <option value="error">error</option>
              <option value="silent">silent</option>
            </select>
          </label>

          <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
            scope
            <input
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              className="w-40 rounded-lg border border-slate-200 bg-white px-2 py-1"
              placeholder="ui/auth/upload"
            />
          </label>

          <button
            type="button"
            onClick={() => setEvents([])}
            className="rounded-xl border border-slate-200 bg-white px-3 py-2 hover:bg-slate-50 transition"
          >
            Clear
          </button>
        </div>
      </header>

      <section className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
          <h3 className="font-semibold">Actions</h3>
          <p className="text-sm text-slate-600">Clique pour produire des logs. Observe le filtrage par niveau.</p>

          <div className="flex flex-wrap gap-2">
            <button
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
              onClick={() => log.debug("Debug: state snapshot", { open: true, count: 3 })}
            >
              debug
            </button>
            <button
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
              onClick={() => log.info("Info: user action", { action: "click" })}
            >
              info
            </button>
            <button
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
              onClick={() => log.warn("Warn: rate limit near", { remaining: 2 })}
            >
              warn
            </button>
            <button
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
              onClick={() => log.error("Error: request failed", { status: 500 }, new Error("boom"))}
            >
              error
            </button>
            <button
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
              onClick={() => log.child("Button").info("Child scope example")}
            >
              child()
            </button>
          </div>

          <div className="text-xs text-slate-500 pt-2">
            Tip : en prod tu peux passer <code>level: "warn"</code> ou <code>enabled: false</code> (preset).
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="flex items-center justify-between px-1 pb-3">
            <h3 className="font-semibold">Log stream</h3>
            {pill(`${events.length} events`)}
          </div>

          <div className="space-y-2 max-h-[420px] overflow-auto pr-1">
            {events.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-600">
                Aucun log. Clique sur “info” ou “error”.
              </div>
            ) : (
              events.map((e, idx) => <LogRow key={idx} e={e} />)
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

const meta: Meta<typeof LoggerDemo> = {
  title: "utils/logger",
  component: LoggerDemo,
  parameters: { layout: "fullscreen" },
};

export default meta;
type Story = StoryObj<typeof LoggerDemo>;
export const Default: Story = {};
