/**
 * logger — logger simple, contrôlé, et extensible
 *
 * Objectif :
 * - Dev : logs lisibles (logger.info / logger.error ...)
 * - Prod : couper / réduire facilement (ou brancher plus tard sur un outil)
 *
 * Bonus : évite les console.log dispersés.
 *
 * Notes :
 * - Purement "présentation / DX" : aucun log métier sensible.
 * - Fonctionne en browser. Si `process.env.NODE_ENV` n'existe pas, on assume "production".
 */

export type LogLevel = "debug" | "info" | "warn" | "error" | "silent";

export type LogEvent = {
  time: Date;
  level: Exclude<LogLevel, "silent">;
  scope?: string;
  message: string;
  /** Meta optionnel (objets, erreurs, payloads). */
  meta?: unknown[];
};

export type LoggerTransport = (event: LogEvent) => void;

export type LoggerOptions = {
  /** Nom/namespace (ex: "ui", "auth", "upload") */
  scope?: string;
  /** Active/désactive globalement. */
  enabled?: boolean;
  /** Niveau minimal à logger. */
  level?: LogLevel;
  /**
   * Si true, log style "dev friendly" (tags + couleurs).
   * Par défaut : true en dev, false en prod.
   */
  pretty?: boolean;
  /** Destinations (console par défaut). */
  transports?: LoggerTransport[];
};

export type Logger = {
  debug: (message: string, ...meta: unknown[]) => void;
  info: (message: string, ...meta: unknown[]) => void;
  warn: (message: string, ...meta: unknown[]) => void;
  error: (message: string, ...meta: unknown[]) => void;

  /** Logger enfant, scoped (ex: logger.child("Button")). */
  child: (scope: string) => Logger;

  /** Ajuste le niveau (runtime). */
  setLevel: (level: LogLevel) => void;
  /** Active/désactive (runtime). */
  setEnabled: (enabled: boolean) => void;

  /** Lecture (utile pour debug/tools). */
  getConfig: () => Readonly<Required<Pick<LoggerOptions, "enabled" | "level" | "pretty">> & { scope?: string }>;
};

const LEVEL_RANK: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  silent: 100,
};

function getNodeEnv(): "development" | "production" {
  // Compatible Vite/Next/Node-like. En browser pur, process peut être undefined.
  const env = (globalThis as any)?.process?.env?.NODE_ENV;
  return env === "development" ? "development" : "production";
}

function defaultPretty() {
  return getNodeEnv() === "development";
}

function shouldLog(level: Exclude<LogLevel, "silent">, minLevel: LogLevel) {
  return LEVEL_RANK[level] >= LEVEL_RANK[minLevel];
}

function toConsoleMethod(level: Exclude<LogLevel, "silent">): (...args: any[]) => void {
  // eslint-disable-next-line no-console
  const c = console;
  switch (level) {
    case "debug":
      return c.debug ? c.debug.bind(c) : c.log.bind(c);
    case "info":
      return c.info ? c.info.bind(c) : c.log.bind(c);
    case "warn":
      return c.warn.bind(c);
    case "error":
      return c.error.bind(c);
  }
}

function formatPrefix(event: LogEvent, pretty: boolean) {
  const time = event.time.toISOString().slice(11, 19); // HH:MM:SS
  const scope = event.scope ? `[${event.scope}]` : "";
  const lvl = event.level.toUpperCase();

  if (!pretty) return `${time} ${lvl}${scope ? " " + scope : ""}`;

  // Style console (dev). On évite les dépendances.
  const label = `${lvl}${scope ? " " + scope : ""}`;
  const styles: Record<LogEvent["level"], string> = {
    debug: "color:#64748b;font-weight:600",
    info: "color:#0f172a;font-weight:600",
    warn: "color:#b45309;font-weight:700",
    error: "color:#be123c;font-weight:800",
  };

  return { time, label, style: styles[event.level] } as const;
}

function createConsoleTransport(pretty: boolean): LoggerTransport {
  return (event) => {
    const log = toConsoleMethod(event.level);

    const prefix = formatPrefix(event, pretty);
    if (typeof prefix === "string") {
      log(prefix, event.message, ...(event.meta ?? []));
      return;
    }

    // pretty
    // eslint-disable-next-line no-console
    log(
      `%c${prefix.label}%c ${prefix.time}`,
      prefix.style,
      "color:#94a3b8;font-weight:500",
      event.message,
      ...(event.meta ?? []),
    );
  };
}

/**
 * createLogger — factory
 */
export function createLogger(options: LoggerOptions = {}): Logger {
  let scope = options.scope;
  let enabled = options.enabled ?? true;
  let level: LogLevel = options.level ?? (getNodeEnv() === "development" ? "debug" : "info");
  let pretty = options.pretty ?? defaultPretty();

  // Console par défaut si aucun transport fourni.
  const transports: LoggerTransport[] =
    options.transports && options.transports.length > 0
      ? [...options.transports]
      : [createConsoleTransport(pretty)];

  function emit(lvl: Exclude<LogLevel, "silent">, message: string, meta: unknown[]) {
    if (!enabled) return;
    if (!shouldLog(lvl, level)) return;

    const event: LogEvent = {
      time: new Date(),
      level: lvl,
      scope,
      message,
      meta: meta.length ? meta : undefined,
    };

    for (const t of transports) t(event);
  }

  const api: Logger = {
    debug: (m, ...meta) => emit("debug", m, meta),
    info: (m, ...meta) => emit("info", m, meta),
    warn: (m, ...meta) => emit("warn", m, meta),
    error: (m, ...meta) => emit("error", m, meta),

    child: (childScope) => {
      const next = scope ? `${scope}/${childScope}` : childScope;
      return createLogger({ ...options, scope: next, enabled, level, pretty, transports });
    },

    setLevel: (next) => {
      level = next;
    },
    setEnabled: (next) => {
      enabled = next;
    },

    getConfig: () => ({ scope, enabled, level, pretty }),
  };

  return api;
}

/**
 * logger — instance par défaut (simple import, sans config)
 *
 * Si tu veux un comportement global (ex: prod silencieux), utilise createLogger()
 * dans un fichier de composition (ex: lib/logger.ts) et exporte-le.
 */
export const logger = createLogger({ scope: "ui" });
