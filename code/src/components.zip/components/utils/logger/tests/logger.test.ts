import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { createLogger } from "../logger";
import type { LogEvent } from "../logger";

describe("logger", () => {
  let debugSpy: any;
  let infoSpy: any;
  let warnSpy: any;
  let errorSpy: any;

  beforeEach(() => {
    debugSpy = vi.spyOn(console, "debug").mockImplementation(() => {});
    infoSpy = vi.spyOn(console, "info").mockImplementation(() => {});
    warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    debugSpy.mockRestore();
    infoSpy.mockRestore();
    warnSpy.mockRestore();
    errorSpy.mockRestore();
  });

  it("loge selon le niveau", () => {
    const l = createLogger({ enabled: true, level: "warn", pretty: false });

    l.debug("d");
    l.info("i");
    l.warn("w");
    l.error("e");

    expect(warnSpy).toHaveBeenCalledTimes(1);
    expect(errorSpy).toHaveBeenCalledTimes(1);
    expect(infoSpy).toHaveBeenCalledTimes(0);
    expect(debugSpy).toHaveBeenCalledTimes(0);
  });

  it("peut être désactivé", () => {
    const l = createLogger({ enabled: false, level: "debug", pretty: false });
    l.error("nope");
    expect(errorSpy).toHaveBeenCalledTimes(0);
  });

  it("compose le scope via child()", () => {
    const events: LogEvent[] = [];
    const transport = (e: LogEvent) => events.push(e);

    const root = createLogger({ scope: "ui", transports: [transport], pretty: false });
    const child = root.child("Button").child("Icon");

    child.info("hello");

    expect(events).toHaveLength(1);
    expect(events[0].scope).toBe("ui/Button/Icon");
  });

  it("passe meta aux transports", () => {
    const events: LogEvent[] = [];
    const transport = (e: LogEvent) => events.push(e);

    const l = createLogger({ transports: [transport], pretty: false });
    l.error("boom", { code: "E1" }, new Error("x"));

    expect(events[0].message).toBe("boom");
    expect(events[0].meta?.length).toBe(2);
  });

  it("setLevel / setEnabled sont appliqués runtime", () => {
    const l = createLogger({ enabled: true, level: "error", pretty: false });

    l.warn("w1");
    expect(warnSpy).toHaveBeenCalledTimes(0);

    l.setLevel("debug");
    l.warn("w2");
    expect(warnSpy).toHaveBeenCalledTimes(1);

    l.setEnabled(false);
    l.error("e1");
    expect(errorSpy).toHaveBeenCalledTimes(0);
  });
});
