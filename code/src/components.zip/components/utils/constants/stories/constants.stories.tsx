import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ANIMATION_MS, BREAKPOINTS_PX, EASING, LIMITS, STORAGE_KEYS, UI_SIZES, Z_INDEX } from "../constants";

type Section = {
  title: string;
  description: string;
  data: Record<string, string | number>;
  monospace?: boolean;
};

const sections: Section[] = [
  {
    title: "UI_SIZES",
    description: "Tailles standard pour variants (S/M/L).",
    data: UI_SIZES,
    monospace: true,
  },
  {
    title: "ANIMATION_MS",
    description: "Durées d’animation (ms) pour cohérence des micro-interactions.",
    data: ANIMATION_MS,
  },
  {
    title: "EASING",
    description: "Easing CSS partagés.",
    data: EASING,
    monospace: true,
  },
  {
    title: "Z_INDEX",
    description: "Couches UI (dropdown, modal, toast, tooltip…).",
    data: Z_INDEX,
  },
  {
    title: "STORAGE_KEYS",
    description: "Clés de storage prefixées pour éviter collisions.",
    data: STORAGE_KEYS,
    monospace: true,
  },
  {
    title: "LIMITS",
    description: "Limites UI (validation côté client).",
    data: LIMITS,
  },
  {
    title: "BREAKPOINTS_PX",
    description: "Breakpoints en px (utile côté JS).",
    data: BREAKPOINTS_PX,
  },
];

function Pill({ children }: { children: React.ReactNode }) {
  return <span className="text-xs px-2 py-1 rounded-full border border-slate-200 text-slate-600">{children}</span>;
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = React.useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 900);
        } catch {
          // ignore (storybook iframe permissions peuvent varier)
        }
      }}
      className="text-xs rounded-lg border border-slate-200 bg-white px-2 py-1 hover:bg-slate-50 transition"
      aria-label="Copier la valeur"
    >
      {copied ? "Copié" : "Copier"}
    </button>
  );
}

function Row({ k, v, monospace }: { k: string; v: string | number; monospace?: boolean }) {
  const value = typeof v === "string" ? `"${v}"` : String(v);
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-3 py-2">
      <div className="min-w-0">
        <div className="text-sm font-medium text-slate-900">{k}</div>
        <div className={monospace ? "font-mono text-xs text-slate-600 break-all" : "text-xs text-slate-600 break-all"}>
          {value}
        </div>
      </div>
      <CopyButton value={value} />
    </div>
  );
}

function ConstantsDemo() {
  const [q, setQ] = React.useState("");

  const filtered = React.useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return sections;

    return sections
      .map((s) => {
        const entries = Object.entries(s.data).filter(([k, v]) => {
          const vv = typeof v === "string" ? v : String(v);
          return k.toLowerCase().includes(query) || vv.toLowerCase().includes(query);
        });
        return { ...s, data: Object.fromEntries(entries) };
      })
      .filter((s) => Object.keys(s.data).length > 0);
  }, [q]);

  return (
    <div className="p-6 space-y-6">
      <header className="space-y-2">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">constants — UI shared constants</h2>
            <p className="text-sm text-slate-600">
              Stocke tailles, durées d’animation, z-index, storage keys, limites… pour éviter les “magic numbers”.
            </p>
          </div>
          <Pill>utils/constants</Pill>
        </div>

        <div className="flex items-center gap-3">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher une constante (ex: MODAL, ui:, 180, MAX_)"
            className="w-full max-w-xl rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-slate-300"
          />
          <button
            type="button"
            onClick={() => setQ("")}
            className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 transition"
          >
            Reset
          </button>
        </div>
      </header>

      <div className="grid lg:grid-cols-2 gap-6">
        {filtered.map((s) => (
          <section key={s.title} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="px-1 pb-3">
              <div className="flex items-center justify-between gap-3">
                <h3 className="font-semibold">{s.title}</h3>
                <Pill>{Object.keys(s.data).length} items</Pill>
              </div>
              <p className="text-sm text-slate-600">{s.description}</p>
            </div>

            <div className="space-y-2">
              {Object.entries(s.data).map(([k, v]) => (
                <Row key={k} k={k} v={v} monospace={s.monospace} />
              ))}
            </div>
          </section>
        ))}
      </div>

      <footer className="text-xs text-slate-500">
        Note : ces constantes sont pour l’UI. Les vraies règles doivent aussi être validées côté serveur.
      </footer>
    </div>
  );
}

const meta: Meta<typeof ConstantsDemo> = {
  title: "utils/constants",
  component: ConstantsDemo,
  parameters: { layout: "fullscreen" },
};

export default meta;
type Story = StoryObj<typeof ConstantsDemo>;
export const Default: Story = {};
