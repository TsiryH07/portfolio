import { describe, expect, it } from "vitest";
import { ANIMATION_MS, BREAKPOINTS_PX, LIMITS, STORAGE_KEYS, UI_SIZES, Z_INDEX } from "../constants";

describe("constants", () => {
  it("UI_SIZES contient sm/md/lg", () => {
    expect(UI_SIZES.SM).toBe("sm");
    expect(UI_SIZES.MD).toBe("md");
    expect(UI_SIZES.LG).toBe("lg");
  });

  it("ANIMATION_MS est cohérent (valeurs positives)", () => {
    expect(ANIMATION_MS.INSTANT).toBeGreaterThanOrEqual(0);
    expect(ANIMATION_MS.FAST).toBeGreaterThan(0);
    expect(ANIMATION_MS.NORMAL).toBeGreaterThan(ANIMATION_MS.FAST);
  });

  it("Z_INDEX garde un ordre logique", () => {
    expect(Z_INDEX.DROPDOWN).toBeGreaterThan(Z_INDEX.HEADER);
    expect(Z_INDEX.MODAL).toBeGreaterThan(Z_INDEX.OVERLAY);
    expect(Z_INDEX.TOOLTIP).toBeGreaterThan(Z_INDEX.TOAST);
  });

  it("STORAGE_KEYS utilise des prefixes (ui:/auth:/app:)", () => {
    const values = Object.values(STORAGE_KEYS);
    expect(values.every((k) => /^(ui|auth|app):/.test(k))).toBe(true);
  });

  it("LIMITS a des bornes raisonnables", () => {
    expect(LIMITS.MAX_FILE_SIZE_MB).toBeGreaterThan(0);
    expect(LIMITS.MAX_UPLOAD_FILES).toBeGreaterThan(0);
    expect(LIMITS.MIN_PASSWORD_LENGTH).toBeGreaterThanOrEqual(8);
  });

  it("BREAKPOINTS_PX est strictement croissant", () => {
    const list = [BREAKPOINTS_PX.SM, BREAKPOINTS_PX.MD, BREAKPOINTS_PX.LG, BREAKPOINTS_PX.XL, BREAKPOINTS_PX["2XL"]];
    for (let i = 1; i < list.length; i++) {
      expect(list[i]).toBeGreaterThan(list[i - 1]);
    }
  });

  it("les objets sont frozen (anti-mutation accidentelle)", () => {
    expect(Object.isFrozen(UI_SIZES)).toBe(true);
    expect(Object.isFrozen(ANIMATION_MS)).toBe(true);
    expect(Object.isFrozen(Z_INDEX)).toBe(true);
    expect(Object.isFrozen(STORAGE_KEYS)).toBe(true);
    expect(Object.isFrozen(LIMITS)).toBe(true);
    expect(Object.isFrozen(BREAKPOINTS_PX)).toBe(true);
  });
});
