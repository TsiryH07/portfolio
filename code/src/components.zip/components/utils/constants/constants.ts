/**
 * constants — UI shared constants (DX + cohérence)
 *
 * Objectif : stocker des constantes UI partagées (tailles, durées d’animation,
 * z-index, clés de storage, limites UI, etc.) pour éviter les "magic numbers".
 */

// --- Helpers ---------------------------------------------------------------

/**
 * Freeze léger : empêche les mutations accidentelles au runtime (dev).
 * Note: `as const` fait le job côté type. `Object.freeze` protège au runtime.
 */
function freeze<T extends Record<string, any>>(obj: T): Readonly<T> {
  return Object.freeze(obj);
}

// --- Sizes -----------------------------------------------------------------

/** Tailles UI standard (pour variants de composants). */
export const UI_SIZES = freeze({
  SM: "sm",
  MD: "md",
  LG: "lg",
} as const);

export type UiSize = typeof UI_SIZES[keyof typeof UI_SIZES];

/** Si tu veux itérer dans des sélecteurs/controls. */
export const UI_SIZE_LIST = Object.freeze([UI_SIZES.SM, UI_SIZES.MD, UI_SIZES.LG] as const);

// --- Animation -------------------------------------------------------------

/** Durées d'animation (ms) */
export const ANIMATION_MS = freeze({
  INSTANT: 0,
  FAST: 120,
  NORMAL: 180,
  SLOW: 260,
  OVERLAY: 320,
} as const);

export type AnimationMs = typeof ANIMATION_MS[keyof typeof ANIMATION_MS];

/**
 * Classes Tailwind pour les durées d'animation (utiles dans les variants).
 * Tu peux les étendre selon les besoins.
 */
export const UI_DURATIONS = freeze({
  fast: "duration-150",
  normal: "duration-200",
  slow: "duration-300",
} as const);

/** Easing CSS (cohérence micro-interactions) */
export const EASING = freeze({
  STANDARD: "cubic-bezier(0.2, 0, 0, 1)",
  EMPHASIZED: "cubic-bezier(0.2, 0, 0, 1.2)",
  LINEAR: "linear",
} as const);

export type Easing = typeof EASING[keyof typeof EASING];

// --- Layering --------------------------------------------------------------

/**
 * Z-index (layers)
 * Convention : plus c'est "global", plus la valeur est haute.
 */
export const Z_INDEX = freeze({
  BASE: 0,
  HEADER: 20,
  DROPDOWN: 50,
  OVERLAY: 80,
  MODAL: 100,
  TOAST: 110,
  TOOLTIP: 120,
  DEVTOOLS: 9999,
} as const);

export type ZIndexLayer = keyof typeof Z_INDEX;

// --- Storage keys ----------------------------------------------------------

/**
 * Clés de storage (localStorage/sessionStorage)
 * Convention : prefix par scope ("ui:", "auth:", "app:") pour éviter collisions.
 */
export const STORAGE_KEYS = freeze({
  UI_THEME: "ui:theme",
  UI_SIDEBAR: "ui:sidebar",
  UI_LOCALE: "ui:locale",
  AUTH_TOKEN: "auth:token",
  APP_ONBOARDING: "app:onboarding",
} as const);

export type StorageKey = typeof STORAGE_KEYS[keyof typeof STORAGE_KEYS];

// --- Limits ----------------------------------------------------------------

/**
 * Limites UI (validation côté client)
 * ⚠️ IMPORTANT : la validation serveur doit aussi exister dans `features/*` ou `lib/*`.
 */
export const LIMITS = freeze({
  MAX_FILE_SIZE_MB: 10,
  MAX_UPLOAD_FILES: 5,
  MAX_TEXTAREA_CHARS: 5_000,
  MAX_TAGS: 12,
  MIN_PASSWORD_LENGTH: 8,
} as const);

export type LimitKey = keyof typeof LIMITS;

// --- Breakpoints (optionnel mais pratique) ---------------------------------

/** Breakpoints en px (quand tu en as besoin côté JS) */
export const BREAKPOINTS_PX = freeze({
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  "2XL": 1536,
} as const);

export type Breakpoint = keyof typeof BREAKPOINTS_PX;

// --- Radii -----------------------------------------------------------------

/** Rayon de bordure standardisés pour les composants UI. */
export const UI_RADII = freeze({
  sm: "rounded-md",
  md: "rounded-lg",
  lg: "rounded-xl",
  full: "rounded-full",
} as const);
