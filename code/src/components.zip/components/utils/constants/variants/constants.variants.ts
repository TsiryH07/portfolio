/**
 * Variants (curation) — helpers qui combinent des constantes pour des usages courants.
 * Un util de constantes n'a pas de "variants UI", mais on conserve le dossier pour cohérence.
 */

import { ANIMATION_MS, EASING, UI_SIZES, Z_INDEX } from "../constants";

export const motionPresets = Object.freeze({
  fadeIn: {
    durationMs: ANIMATION_MS.NORMAL,
    easing: EASING.STANDARD,
  },
  pop: {
    durationMs: ANIMATION_MS.FAST,
    easing: EASING.EMPHASIZED,
  },
} as const);

export const defaultUi = Object.freeze({
  size: UI_SIZES.MD,
  modalZIndex: Z_INDEX.MODAL,
} as const);
