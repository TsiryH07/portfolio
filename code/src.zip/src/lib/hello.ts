export const hello = () => 'hello';
