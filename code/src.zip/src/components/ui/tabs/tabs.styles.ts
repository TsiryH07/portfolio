import { cva } from 'class-variance-authority';

export const tabsListStyles = cva(
  'inline-flex items-center justify-center gap-1 rounded-2xl border border-border/70 bg-surface-muted p-1 text-muted-foreground shadow-soft',
  {
    variants: {
      size: {
        sm: 'h-9',
        md: 'h-10',
        lg: 'h-12',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  },
);

export const tabsTriggerStyles = cva(
  'inline-flex items-center justify-center whitespace-nowrap rounded-xl px-3 py-1 text-sm font-semibold transition-all duration-150 ease-[var(--transition-smooth)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-surface data-[state=active]:text-foreground data-[state=active]:shadow-soft data-[state=active]:border data-[state=active]:border-border/70',
  {
    variants: {
      size: {
        sm: 'h-7 text-xs',
        md: 'h-8',
        lg: 'h-10 text-base px-4',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  },
);

export const tabsContentStyles = cva(
  'mt-3 rounded-2xl border border-border/70 bg-surface p-4 text-sm shadow-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
);
