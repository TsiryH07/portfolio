import type * as React from 'react';
import type { VariantProps } from 'class-variance-authority';

import type { inputStyles } from './input.styles';

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    VariantProps<typeof inputStyles> {}
