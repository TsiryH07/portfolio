import {ThemeToggle} from "@/components/common/theme-toggle";

export function Navbar() {
  return (
    <header>
      <ThemeToggle />
    </header>
  );
}
