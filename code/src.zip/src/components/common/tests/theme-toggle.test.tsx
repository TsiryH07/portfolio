import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {vi} from "vitest";

import {ThemeToggle} from "../theme-toggle";

const mockUseTheme = vi.hoisted(() => vi.fn());

vi.mock("next-themes", () => ({
  useTheme: mockUseTheme,
}));

describe("ThemeToggle", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('affiche "Light" quand le thème est dark', () => {
    const setTheme = vi.fn();
    mockUseTheme.mockReturnValue({resolvedTheme: "dark", setTheme});

    render(<ThemeToggle />);

    expect(screen.getByRole("button")).toHaveTextContent("Light");
  });

  it('bascule vers "light" quand on clique depuis le thème dark', async () => {
    const user = userEvent.setup();
    const setTheme = vi.fn();
    mockUseTheme.mockReturnValue({resolvedTheme: "dark", setTheme});

    render(<ThemeToggle />);
    await user.click(screen.getByRole("button"));

    expect(setTheme).toHaveBeenCalledWith("light");
  });

  it('affiche "Dark" quand le thème est light et bascule vers "dark" au clic', async () => {
    const user = userEvent.setup();
    const setTheme = vi.fn();
    mockUseTheme.mockReturnValue({resolvedTheme: "light", setTheme});

    render(<ThemeToggle />);
    expect(screen.getByRole("button")).toHaveTextContent("Dark");

    await user.click(screen.getByRole("button"));
    expect(setTheme).toHaveBeenCalledWith("dark");
  });
});
