import '@testing-library/jest-dom/vitest';

// Add shared test setup (mocks, global configs) here if needed.
