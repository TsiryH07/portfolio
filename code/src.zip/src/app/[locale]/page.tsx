import {useTranslations} from "next-intl";

import {ProjectsView} from "@/features/projects/components/projects-view";

export default function ProjectsPage() {
  const t = useTranslations("HomePage");

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">{t("title")}</h1>
      <ProjectsView />
    </div>
  );
}
