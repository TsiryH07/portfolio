export default function AboutPage() {
  return (
    <section className="mx-auto max-w-3xl space-y-4 px-6 py-12">
      <h1 className="text-3xl font-bold tracking-tight">A propos</h1>
      <p className="text-sm text-muted-foreground">
        Cette page est en cours de construction.
      </p>
    </section>
  );
}
