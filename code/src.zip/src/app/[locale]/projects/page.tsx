import { ProjectsView } from '@/features/projects/components/projects-view';

export default function ProjectsPage() {
  return (
    <section className="mx-auto max-w-4xl space-y-6 px-6 py-12">
      <h1 className="text-3xl font-bold tracking-tight">Projets</h1>
      <ProjectsView />
    </section>
  );
}
