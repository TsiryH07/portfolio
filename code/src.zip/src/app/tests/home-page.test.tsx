import {render, screen} from "@testing-library/react";
import {NextIntlClientProvider} from "next-intl";

import HomePage from "../[locale]/page";

describe("HomePage", () => {
  it("affiche le titre traduit", () => {
    render(
      <NextIntlClientProvider
        locale="fr"
        messages={{HomePage: {title: "Bienvenue"}}}
      >
        <HomePage />
      </NextIntlClientProvider>
    );

    expect(screen.getByRole("heading", {level: 1})).toHaveTextContent(
      "Bienvenue"
    );
  });
});
